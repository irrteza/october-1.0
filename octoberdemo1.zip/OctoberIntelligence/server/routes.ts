import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { setupWebSocket } from "./services/websocket";
import { z } from "zod";
import {
  insertCampaignSchema,
  insertDeliverableSchema,
  insertCreatorSchema,
  insertMetricSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);
      
      // Auto-create user if not exists (for demo)
      if (!user) {
        user = await storage.upsertUser({
          id: userId,
          email: req.user.claims.email,
          firstName: req.user.claims.first_name,
          lastName: req.user.claims.last_name,
          profileImageUrl: req.user.claims.profile_image_url,
        });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user role (for demo purposes)
  app.patch('/api/auth/user/role', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { role } = req.body;
      
      if (!['owner', 'manager', 'creator', 'viewer'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      const user = await storage.updateUserRole(userId, role);
      res.json(user);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update role" });
    }
  });

  // Dashboard routes
  app.get("/api/dashboard/metrics", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user?.accountId) {
        return res.status(400).json({ message: "User not associated with an account" });
      }

      const metrics = await storage.getDashboardMetrics(user.accountId);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Campaign routes
  app.get("/api/campaigns", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);
      
      // Auto-create user if not exists (for demo)
      if (!user) {
        user = await storage.upsertUser({
          id: userId,
          email: req.user.claims.email,
          firstName: req.user.claims.first_name,
          lastName: req.user.claims.last_name,
          profileImageUrl: req.user.claims.profile_image_url,
        });
      }
      
      if (!user?.accountId) {
        return res.status(400).json({ message: "User not associated with an account" });
      }

      const campaigns = await storage.getCampaigns(user.accountId);
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.post("/api/campaigns", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user?.accountId) {
        return res.status(400).json({ message: "User not associated with an account" });
      }

      const validatedData = insertCampaignSchema.parse({
        ...req.body,
        accountId: user.accountId,
      });

      const campaign = await storage.createCampaign(validatedData);
      
      // Award points for creating campaign
      await storage.addPoints(userId, 25, "campaign_created", `Created campaign: ${campaign.name}`);
      
      res.json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  // Deliverable routes
  app.get("/api/deliverables", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { campaignId, status } = req.query;

      let filters: any = {};
      if (campaignId) filters.campaignId = campaignId as string;
      if (status) filters.status = status as string;

      // If user is a creator, only show their deliverables
      if (user?.role === "creator") {
        const creator = await storage.getCreatorByUserId(userId);
        if (creator) {
          filters.creatorId = creator.id;
        }
      }

      const deliverables = await storage.getDeliverables(filters);
      res.json(deliverables);
    } catch (error) {
      console.error("Error fetching deliverables:", error);
      res.status(500).json({ message: "Failed to fetch deliverables" });
    }
  });

  app.post("/api/deliverables", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertDeliverableSchema.parse(req.body);
      const deliverable = await storage.createDeliverable(validatedData);
      res.json(deliverable);
    } catch (error) {
      console.error("Error creating deliverable:", error);
      res.status(500).json({ message: "Failed to create deliverable" });
    }
  });

  app.patch("/api/deliverables/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status, ...data } = req.body;
      const userId = req.user.claims.sub;

      await storage.updateDeliverableStatus(id, status, data);

      // Award points based on status changes
      if (status === "approved") {
        await storage.addPoints(userId, 30, "deliverable_approved", `Deliverable approved: ${id}`);
      } else if (status === "live") {
        await storage.addPoints(userId, 50, "deliverable_live", `Deliverable went live: ${id}`);
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error updating deliverable status:", error);
      res.status(500).json({ message: "Failed to update deliverable status" });
    }
  });

  // Creator routes
  app.get("/api/creators", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const creators = await storage.getCreators(user?.accountId || undefined);
      res.json(creators);
    } catch (error) {
      console.error("Error fetching creators:", error);
      res.status(500).json({ message: "Failed to fetch creators" });
    }
  });

  app.get("/api/creators/top", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);
      
      // Auto-create user if not exists (for demo)
      if (!user) {
        user = await storage.upsertUser({
          id: userId,
          email: req.user.claims.email,
          firstName: req.user.claims.first_name,
          lastName: req.user.claims.last_name,
          profileImageUrl: req.user.claims.profile_image_url,
        });
      }
      
      if (!user?.accountId) {
        return res.status(400).json({ message: "User not associated with an account" });
      }

      const limit = parseInt(req.query.limit as string) || 10;
      const topCreators = await storage.getTopCreators(user.accountId, limit);
      res.json(topCreators);
    } catch (error) {
      console.error("Error fetching top creators:", error);
      res.status(500).json({ message: "Failed to fetch top creators" });
    }
  });

  app.post("/api/creators", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertCreatorSchema.parse(req.body);
      const creator = await storage.createCreator(validatedData);
      res.json(creator);
    } catch (error) {
      console.error("Error creating creator:", error);
      res.status(500).json({ message: "Failed to create creator" });
    }
  });

  // Metrics routes
  app.post("/api/metrics", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertMetricSchema.parse(req.body);
      const metric = await storage.createMetric(validatedData);
      res.json(metric);
    } catch (error) {
      console.error("Error creating metric:", error);
      res.status(500).json({ message: "Failed to create metric" });
    }
  });

  app.get("/api/metrics/campaign/:campaignId", isAuthenticated, async (req: any, res) => {
    try {
      const { campaignId } = req.params;
      const metrics = await storage.getCampaignMetrics(campaignId);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching campaign metrics:", error);
      res.status(500).json({ message: "Failed to fetch campaign metrics" });
    }
  });

  // Points routes
  app.get("/api/points", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const points = await storage.getUserPoints(userId);
      const logs = await storage.getPointsLogs(userId);
      res.json({ points, logs });
    } catch (error) {
      console.error("Error fetching points:", error);
      res.status(500).json({ message: "Failed to fetch points" });
    }
  });

  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const unreadOnly = req.query.unreadOnly === "true";
      const notifications = await storage.getUserNotifications(userId, unreadOnly);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationRead(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Invoice routes
  app.get("/api/invoices", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { status } = req.query;

      let filters: any = {};
      if (status) filters.status = status as string;

      // If user is a creator, only show their invoices
      if (user?.role === "creator") {
        const creator = await storage.getCreatorByUserId(userId);
        if (creator) {
          filters.creatorId = creator.id;
        }
      }

      const invoices = await storage.getInvoices(filters);
      res.json(invoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  const httpServer = createServer(app);

  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  setupWebSocket(wss);

  return httpServer;
}
