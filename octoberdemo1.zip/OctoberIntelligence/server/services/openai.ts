import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface CreatorMatchRequest {
  referenceCreatorId: string;
  platform: string;
  audience?: string;
  budget?: number;
}

export interface CreatorMatchResult {
  creatorId: string;
  similarityScore: number;
  reasoning: string;
  estimatedRate: number;
}

export interface BriefCopilotRequest {
  productUrl: string;
  brand: string;
  targetAudience: string;
  platform: string;
}

export interface BriefCopilotResult {
  title: string;
  description: string;
  keyMessages: string[];
  hashtags: string[];
  requirements: {
    duration?: number;
    deliveryFormat: string;
    mentions: string[];
  };
}

export interface RateAdvisorRequest {
  creatorProfile: {
    followersCount: number;
    engagementRate: number;
    platform: string;
    niche: string;
  };
  deliverableType: string;
  campaignBudget?: number;
}

export interface RateAdvisorResult {
  recommendedRate: number;
  range: {
    min: number;
    max: number;
  };
  factors: string[];
  confidence: number;
}

export class OpenAIService {
  async findSimilarCreators(request: CreatorMatchRequest): Promise<CreatorMatchResult[]> {
    try {
      const prompt = `
        You are an expert influencer marketing strategist. Analyze the reference creator and suggest similar creators.
        
        Reference Creator ID: ${request.referenceCreatorId}
        Platform: ${request.platform}
        Target Audience: ${request.audience || "General"}
        Budget Range: ${request.budget ? `$${request.budget}` : "Not specified"}
        
        Based on typical creator characteristics, suggest 5 similar creators with their similarity scores, reasoning, and estimated rates.
        Respond with JSON in this format:
        {
          "creators": [
            {
              "creatorId": "suggested_creator_id",
              "similarityScore": 0.85,
              "reasoning": "Similar audience demographics and content style",
              "estimatedRate": 2500
            }
          ]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert influencer marketing AI assistant. Provide data-driven recommendations for creator matching.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result.creators || [];
    } catch (error) {
      console.error("Error finding similar creators:", error);
      throw new Error("Failed to find similar creators");
    }
  }

  async generateContentBrief(request: BriefCopilotRequest): Promise<BriefCopilotResult> {
    try {
      const prompt = `
        You are a creative content strategist. Generate a comprehensive content brief based on the product information.
        
        Product URL: ${request.productUrl}
        Brand: ${request.brand}
        Target Audience: ${request.targetAudience}
        Platform: ${request.platform}
        
        Create a detailed content brief including title, description, key messages, hashtags, and technical requirements.
        Respond with JSON in this format:
        {
          "title": "Engaging content title",
          "description": "Detailed content description and storyline",
          "keyMessages": ["Key message 1", "Key message 2"],
          "hashtags": ["#hashtag1", "#hashtag2"],
          "requirements": {
            "duration": 60,
            "deliveryFormat": "MP4 1080p",
            "mentions": ["@brand", "@product"]
          }
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert content strategist specializing in influencer marketing campaigns. Create compelling and effective content briefs.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result;
    } catch (error) {
      console.error("Error generating content brief:", error);
      throw new Error("Failed to generate content brief");
    }
  }

  async recommendCreatorRate(request: RateAdvisorRequest): Promise<RateAdvisorResult> {
    try {
      const prompt = `
        You are a pricing expert for influencer marketing. Analyze the creator profile and recommend fair pricing.
        
        Creator Profile:
        - Followers: ${request.creatorProfile.followersCount}
        - Engagement Rate: ${request.creatorProfile.engagementRate}%
        - Platform: ${request.creatorProfile.platform}
        - Niche: ${request.creatorProfile.niche}
        
        Deliverable Type: ${request.deliverableType}
        Campaign Budget: ${request.campaignBudget ? `$${request.campaignBudget}` : "Not specified"}
        
        Provide a recommended rate with range and factors considered.
        Respond with JSON in this format:
        {
          "recommendedRate": 2500,
          "range": {
            "min": 2000,
            "max": 3000
          },
          "factors": ["High engagement rate", "Premium niche", "Platform reach"],
          "confidence": 0.85
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a pricing expert for influencer marketing with deep knowledge of industry rates and market dynamics.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result;
    } catch (error) {
      console.error("Error recommending creator rate:", error);
      throw new Error("Failed to recommend creator rate");
    }
  }

  async analyzeContent(contentUrl: string, contentType: string): Promise<{
    sentiment: number;
    topics: string[];
    brandMentions: string[];
    performance_prediction: number;
  }> {
    try {
      const prompt = `
        Analyze this ${contentType} content and provide insights on sentiment, topics, brand mentions, and performance prediction.
        Content URL: ${contentUrl}
        
        Respond with JSON in this format:
        {
          "sentiment": 0.8,
          "topics": ["fashion", "lifestyle", "beauty"],
          "brandMentions": ["@brand1", "@brand2"],
          "performance_prediction": 0.75
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a content analysis expert specializing in social media and influencer marketing performance.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result;
    } catch (error) {
      console.error("Error analyzing content:", error);
      throw new Error("Failed to analyze content");
    }
  }
}

export const openaiService = new OpenAIService();
