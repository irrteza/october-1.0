import Stripe from "stripe";
import { storage } from "../storage";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

export class StripeService {
  async createConnectAccount(creatorId: string, email: string): Promise<string> {
    try {
      const account = await stripe.accounts.create({
        type: "express",
        email,
        capabilities: {
          transfers: { requested: true },
        },
      });

      return account.id;
    } catch (error) {
      console.error("Error creating Stripe Connect account:", error);
      throw new Error("Failed to create Stripe Connect account");
    }
  }

  async createAccountLink(accountId: string, refreshUrl: string, returnUrl: string): Promise<string> {
    try {
      const accountLink = await stripe.accountLinks.create({
        account: accountId,
        refresh_url: refreshUrl,
        return_url: returnUrl,
        type: "account_onboarding",
      });

      return accountLink.url;
    } catch (error) {
      console.error("Error creating account link:", error);
      throw new Error("Failed to create account link");
    }
  }

  async createTransfer(amount: number, destinationAccount: string, transferGroup?: string): Promise<string> {
    try {
      const transfer = await stripe.transfers.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        destination: destinationAccount,
        transfer_group: transferGroup,
      });

      return transfer.id;
    } catch (error) {
      console.error("Error creating transfer:", error);
      throw new Error("Failed to create transfer");
    }
  }

  async processCreatorPayout(
    invoiceId: string,
    creatorConnectAccountId: string,
    amount: number,
    platformFeePercent: number = 0.1
  ): Promise<void> {
    try {
      const platformFee = amount * platformFeePercent;
      const creatorPayout = amount - platformFee;

      // Create transfer to creator
      const transferId = await this.createTransfer(
        creatorPayout,
        creatorConnectAccountId,
        `invoice_${invoiceId}`
      );

      // Update invoice with payment details
      await storage.updateInvoiceStatus(invoiceId, "paid", new Date());

      console.log(`Payout processed: $${creatorPayout} to creator, $${platformFee} platform fee`);
    } catch (error) {
      console.error("Error processing creator payout:", error);
      throw new Error("Failed to process creator payout");
    }
  }

  async processPaymentBasedOnRules(deliverableId: string): Promise<void> {
    try {
      const deliverable = await storage.getDeliverable(deliverableId);
      if (!deliverable?.paymentRules) return;

      const metrics = await storage.getMetrics(deliverableId);
      const latestMetrics = metrics[0];

      if (!latestMetrics) return;

      for (const milestone of deliverable.paymentRules.milestones) {
        const shouldPay = this.evaluatePaymentTrigger(milestone.trigger, latestMetrics, deliverable);
        
        if (shouldPay) {
          const amount = (deliverable.amountDue || 0) * (milestone.percentage / 100);
          
          // Create invoice for this milestone
          const invoice = await storage.createInvoice({
            campaignId: deliverable.campaignId,
            creatorId: deliverable.creatorId,
            invoiceNumber: `INV-${Date.now()}`,
            amount: amount.toString(),
            status: "pending",
            dueDate: new Date(),
            splits: [
              {
                recipientId: deliverable.creatorId,
                amount: amount * 0.9, // 90% to creator
                type: "creator",
              },
              {
                recipientId: "platform",
                amount: amount * 0.1, // 10% platform fee
                type: "platform",
              },
            ],
          });

          console.log(`Payment milestone triggered: ${milestone.description} - $${amount}`);
        }
      }
    } catch (error) {
      console.error("Error processing payment rules:", error);
      throw new Error("Failed to process payment rules");
    }
  }

  private evaluatePaymentTrigger(trigger: string, metrics: any, deliverable: any): boolean {
    // Simple trigger evaluation logic
    if (trigger.includes("approval") && deliverable.status === "approved") {
      return true;
    }
    
    if (trigger.includes("views")) {
      const viewsRequired = parseInt(trigger.match(/(\d+)/)?.[1] || "0");
      return metrics.views >= viewsRequired;
    }
    
    if (trigger.includes("days after") && deliverable.publishedAt) {
      const daysRequired = parseInt(trigger.match(/(\d+)/)?.[1] || "0");
      const daysSincePublished = Math.floor(
        (Date.now() - new Date(deliverable.publishedAt).getTime()) / (1000 * 60 * 60 * 24)
      );
      return daysSincePublished >= daysRequired;
    }

    return false;
  }

  async createPaymentIntent(amount: number, customerId?: string): Promise<string> {
    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100),
        currency: "usd",
        customer: customerId,
      });

      return paymentIntent.client_secret!;
    } catch (error) {
      console.error("Error creating payment intent:", error);
      throw new Error("Failed to create payment intent");
    }
  }

  async handleWebhook(signature: string, payload: string): Promise<void> {
    try {
      const event = stripe.webhooks.constructEvent(
        payload,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET!
      );

      switch (event.type) {
        case "account.updated":
          // Handle Connect account updates
          break;
        case "transfer.created":
          // Handle transfer completion
          break;
        case "payment_intent.succeeded":
          // Handle successful payments
          break;
        default:
          console.log(`Unhandled event type: ${event.type}`);
      }
    } catch (error) {
      console.error("Error handling Stripe webhook:", error);
      throw new Error("Failed to handle Stripe webhook");
    }
  }
}

export const stripeService = new StripeService();
