import { WebSocketServer, WebSocket } from "ws";
import { storage } from "../storage";

interface ConnectedClient {
  ws: WebSocket;
  userId: string;
  accountId?: string;
}

export class WebSocketService {
  private clients: Map<string, ConnectedClient> = new Map();
  private wss: WebSocketServer;

  constructor(wss: WebSocketServer) {
    this.wss = wss;
    this.setupWebSocketServer();
  }

  private setupWebSocketServer() {
    this.wss.on("connection", (ws: WebSocket, request) => {
      console.log("New WebSocket connection");

      ws.on("message", async (message: string) => {
        try {
          const data = JSON.parse(message);
          await this.handleMessage(ws, data);
        } catch (error) {
          console.error("Error handling WebSocket message:", error);
          ws.send(JSON.stringify({ type: "error", message: "Invalid message format" }));
        }
      });

      ws.on("close", () => {
        // Remove client from connected clients
        for (const [clientId, client] of this.clients.entries()) {
          if (client.ws === ws) {
            this.clients.delete(clientId);
            console.log(`Client ${clientId} disconnected`);
            break;
          }
        }
      });

      ws.on("error", (error) => {
        console.error("WebSocket error:", error);
      });
    });
  }

  private async handleMessage(ws: WebSocket, data: any) {
    switch (data.type) {
      case "authenticate":
        await this.authenticateClient(ws, data);
        break;
      case "join_campaign":
        await this.joinCampaignRoom(ws, data.campaignId);
        break;
      case "deliverable_update":
        await this.handleDeliverableUpdate(data);
        break;
      case "board_sync":
        await this.syncBoard(data.campaignId);
        break;
      default:
        ws.send(JSON.stringify({ type: "error", message: "Unknown message type" }));
    }
  }

  private async authenticateClient(ws: WebSocket, data: any) {
    try {
      // In a real implementation, you'd validate the auth token here
      const { userId, token } = data;
      
      if (!userId || !token) {
        ws.send(JSON.stringify({ type: "auth_error", message: "Missing credentials" }));
        return;
      }

      const user = await storage.getUser(userId);
      if (!user) {
        ws.send(JSON.stringify({ type: "auth_error", message: "Invalid user" }));
        return;
      }

      const clientId = `${userId}_${Date.now()}`;
      this.clients.set(clientId, {
        ws,
        userId,
        accountId: user.accountId,
      });

      ws.send(JSON.stringify({ 
        type: "authenticated", 
        clientId,
        user: { id: user.id, role: user.role, tier: user.tier }
      }));

      console.log(`Client ${clientId} authenticated as user ${userId}`);
    } catch (error) {
      console.error("Error authenticating client:", error);
      ws.send(JSON.stringify({ type: "auth_error", message: "Authentication failed" }));
    }
  }

  private async joinCampaignRoom(ws: WebSocket, campaignId: string) {
    // Send initial campaign data
    const deliverables = await storage.getDeliverables({ campaignId });
    ws.send(JSON.stringify({
      type: "campaign_data",
      campaignId,
      deliverables,
    }));
  }

  private async handleDeliverableUpdate(data: any) {
    const { deliverableId, updates, campaignId } = data;
    
    // Update deliverable in database
    await storage.updateDeliverableStatus(deliverableId, updates.status, updates);
    
    // Broadcast update to all clients in the campaign
    await this.broadcastToAccountClients(campaignId, {
      type: "deliverable_updated",
      deliverableId,
      updates,
      timestamp: new Date().toISOString(),
    });
  }

  private async syncBoard(campaignId: string) {
    const deliverables = await storage.getDeliverables({ campaignId });
    
    await this.broadcastToAccountClients(campaignId, {
      type: "board_sync",
      campaignId,
      deliverables,
      timestamp: new Date().toISOString(),
    });
  }

  public async broadcastToAccountClients(accountId: string, message: any) {
    for (const [clientId, client] of this.clients.entries()) {
      if (client.accountId === accountId && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    }
  }

  public async broadcastToUser(userId: string, message: any) {
    for (const [clientId, client] of this.clients.entries()) {
      if (client.userId === userId && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    }
  }

  public async notifyDeliverableStatusChange(
    deliverableId: string,
    newStatus: string,
    campaignId: string
  ) {
    const campaign = await storage.getCampaign(campaignId);
    if (!campaign) return;

    await this.broadcastToAccountClients(campaign.accountId, {
      type: "deliverable_status_changed",
      deliverableId,
      newStatus,
      campaignId,
      timestamp: new Date().toISOString(),
    });
  }

  public async notifyNewNotification(userId: string, notification: any) {
    await this.broadcastToUser(userId, {
      type: "new_notification",
      notification,
      timestamp: new Date().toISOString(),
    });
  }

  public async notifyPointsAwarded(userId: string, points: number, reason: string) {
    const userPoints = await storage.getUserPoints(userId);
    
    await this.broadcastToUser(userId, {
      type: "points_awarded",
      delta: points,
      total: userPoints,
      reason,
      timestamp: new Date().toISOString(),
    });
  }
}

let wsService: WebSocketService;

export function setupWebSocket(wss: WebSocketServer) {
  wsService = new WebSocketService(wss);
  return wsService;
}

export function getWebSocketService(): WebSocketService {
  return wsService;
}
