import {
  type User,
  type UpsertUser,
  type Account,
  type InsertAccount,
  type Creator,
  type InsertCreator,
  type Campaign,
  type InsertCampaign,
  type Deliverable,
  type InsertDeliverable,
  type Metric,
  type InsertMetric,
  type Invoice,
  type InsertInvoice,
  type PointsLog,
  type InsertPointsLog,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { nanoid } from "nanoid";

// For MVP, use in-memory storage
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Account operations
  createAccount(account: InsertAccount): Promise<Account>;
  getAccountsByUser(userId: string): Promise<Account[]>;
  
  // Creator operations
  createCreator(creator: InsertCreator): Promise<Creator>;
  getCreator(id: string): Promise<Creator | undefined>;
  getCreatorByUserId(userId: string): Promise<Creator | undefined>;
  getCreators(accountId?: string): Promise<Creator[]>;
  updateCreatorEarnings(creatorId: string, amount: number): Promise<void>;
  
  // Campaign operations
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  getCampaign(id: string): Promise<Campaign | undefined>;
  getCampaigns(accountId: string): Promise<Campaign[]>;
  updateCampaignStatus(id: string, status: string): Promise<void>;
  
  // Deliverable operations
  createDeliverable(deliverable: InsertDeliverable): Promise<Deliverable>;
  getDeliverable(id: string): Promise<Deliverable | undefined>;
  getDeliverables(filters?: {
    campaignId?: string;
    creatorId?: string;
    status?: string;
  }): Promise<Deliverable[]>;
  updateDeliverableStatus(id: string, status: string, data?: any): Promise<void>;
  
  // Metrics operations
  createMetric(metric: InsertMetric): Promise<Metric>;
  getMetrics(deliverableId: string): Promise<Metric[]>;
  getCampaignMetrics(campaignId: string): Promise<Metric[]>;
  
  // Invoice operations
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  getInvoice(id: string): Promise<Invoice | undefined>;
  getInvoices(filters?: {
    campaignId?: string;
    creatorId?: string;
    status?: string;
  }): Promise<Invoice[]>;
  updateInvoiceStatus(id: string, status: string, paidAt?: Date): Promise<void>;
  
  // Points operations
  addPoints(userId: string, delta: number, reason: string, description?: string): Promise<PointsLog>;
  getUserPoints(userId: string): Promise<number>;
  getPointsLogs(userId: string): Promise<PointsLog[]>;
  updateUserTier(userId: string): Promise<void>;
  updateUserRole(userId: string, role: string): Promise<User | undefined>;
  
  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string, unreadOnly?: boolean): Promise<Notification[]>;
  markNotificationRead(id: string): Promise<void>;
  
  // Analytics operations
  getDashboardMetrics(accountId: string): Promise<{
    totalSpend: number;
    totalViews: number;
    totalCreators: number;
    averageROI: number;
  }>;
  getTopCreators(accountId: string, limit?: number): Promise<Creator[]>;
}

// Simple in-memory storage for MVP
export class MemStorage implements IStorage {
  private users = new Map<string, User>();
  private accounts = new Map<string, Account>();
  private creators = new Map<string, Creator>();
  private campaigns = new Map<string, Campaign>();
  private deliverables = new Map<string, Deliverable>();
  private metrics = new Map<string, Metric>();
  private invoices = new Map<string, Invoice>();
  private pointsLogs = new Map<string, PointsLog>();
  private notifications = new Map<string, Notification>();

  constructor() {
    this.initializeMockData();
  }

  private initializeMockData() {
    // Create mock campaign
    const mockCampaign: Campaign = {
      id: "campaign-1",
      name: "Spring Fashion Collection",
      accountId: "account-1",
      description: "Promoting our new sustainable spring fashion line",
      status: "active",
      startDate: new Date("2025-03-01"),
      endDate: new Date("2025-04-30"),
      budget: "25000",
      targetAudience: {
        demographics: ["18-35", "female"],
        interests: ["fashion", "sustainability"],
        locations: ["USA", "Europe"]
      },
      marginGoal: "15",
      brandGuidelines: "Use natural lighting, earthy tones, showcase sustainability",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.campaigns.set(mockCampaign.id, mockCampaign);

    // Create mock deliverables
    const mockDeliverables = [
      {
        id: "del-1",
        title: "Instagram Reel - Outfit Styling",
        type: "instagram_story" as const,
        campaignId: "campaign-1",
        creatorId: "creator-1",
        description: "Create a 60-second styling reel featuring 3 outfits",
        status: "brief" as const,
        dueDate: new Date("2025-02-15"),
        fee: "2500",
      },
      {
        id: "del-2", 
        title: "TikTok - Behind the Scenes",
        type: "tiktok_video" as const,
        campaignId: "campaign-1",
        creatorId: "creator-2",
        description: "Show sustainable fashion production process",
        status: "approved" as const,
        dueDate: new Date("2025-02-20"),
        fee: "3000",
      },
      {
        id: "del-3",
        title: "YouTube Review - Full Collection",
        type: "youtube_video" as const,
        campaignId: "campaign-1", 
        creatorId: "creator-3",
        description: "In-depth review of 5 key pieces from the collection",
        status: "live" as const,
        dueDate: new Date("2025-02-10"),
        fee: "5000",
      },
      {
        id: "del-4",
        title: "Instagram Post - Launch Announcement",
        type: "instagram_post" as const,
        campaignId: "campaign-1",
        creatorId: "creator-4", 
        description: "Announce the collection launch with brand story",
        status: "paid" as const,
        dueDate: new Date("2025-01-25"),
        fee: "1500",
      }
    ];

    mockDeliverables.forEach(del => {
      const deliverable: Deliverable = {
        ...del,
        requirements: {
          hashtags: ["#SustainableFashion", "#SpringStyle"],
          mentions: ["@fashionbrand"],
          deliveryFormat: "video"
        },
        submittedAt: del.status === "live" || del.status === "paid" ? new Date() : null,
        submissionUrl: del.status === "live" || del.status === "paid" ? "https://example.com/video" : null,
        approvedAt: del.status === "live" || del.status === "paid" ? new Date() : null,
        paymentStatus: del.status === "paid" ? "completed" : null,
        notes: null,
        paymentRules: {
          milestones: [
            { trigger: "approval", percentage: 50, description: "Upon content approval" },
            { trigger: "publishing", percentage: 50, description: "Upon content going live" }
          ]
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.deliverables.set(deliverable.id, deliverable);
    });

    // Create mock creators
    const mockCreators = [
      {
        id: "creator-1",
        stageName: "StyleByEmma",
        bio: "Fashion influencer focused on sustainable and affordable style",
        socialProfiles: [
          { platform: "instagram", username: "stylebyemma", followersCount: 125000, verificationStatus: true },
          { platform: "tiktok", username: "stylebyemma", followersCount: 89000, verificationStatus: false }
        ]
      },
      {
        id: "creator-2", 
        stageName: "EcoFashionista",
        bio: "Promoting sustainable fashion choices for the conscious consumer",
        socialProfiles: [
          { platform: "tiktok", username: "ecofashionista", followersCount: 234000, verificationStatus: true }
        ]
      },
      {
        id: "creator-3",
        stageName: "Fashion Forward Studio",
        bio: "Professional fashion review channel with detailed analysis",
        socialProfiles: [
          { platform: "youtube", username: "fashionforwardstudio", followersCount: 456000, verificationStatus: true }
        ]
      },
      {
        id: "creator-4",
        stageName: "UrbanStyle",
        bio: "Street style and urban fashion inspiration",
        socialProfiles: [
          { platform: "instagram", username: "urbanstyle", followersCount: 78000, verificationStatus: false }
        ]
      }
    ];

    mockCreators.forEach(creator => {
      const newCreator: Creator = {
        ...creator,
        userId: null,
        paymentProfile: {
          kycStatus: "verified" as const,
          paymentMethods: ["stripe", "paypal"]
        },
        specialties: ["fashion", "lifestyle"],
        averageRate: "2500",
        totalEarnings: "12500",
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.creators.set(newCreator.id, newCreator);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id);
    
    // For demo purposes, auto-assign user to account and set role
    let accountId = existingUser?.accountId || "account-1";
    let role = existingUser?.role || "owner";
    
    // Create demo account if it doesn't exist
    if (!this.accounts.has(accountId)) {
      const demoAccount: Account = {
        id: accountId,
        name: "Demo Agency",
        type: "agency",
        stripeAccountId: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.accounts.set(accountId, demoAccount);
    }

    const user: User = {
      id: userData.id,
      email: userData.email || null,
      firstName: "Moe",
      lastName: "Sarue",
      profileImageUrl: userData.profileImageUrl || null,
      accountId,
      role,
      points: existingUser?.points || 750,
      tier: existingUser?.tier || "gold",
      stripeCustomerId: null,
      stripeConnectAccountId: null,
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date(),
    };
    this.users.set(userData.id, user);
    return user;
  }

  async createAccount(account: InsertAccount): Promise<Account> {
    const newAccount: Account = {
      id: nanoid(),
      name: account.name,
      type: account.type,
      stripeAccountId: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.accounts.set(newAccount.id, newAccount);
    return newAccount;
  }

  async getAccountsByUser(userId: string): Promise<Account[]> {
    // For MVP, return empty array or mock data
    return Array.from(this.accounts.values());
  }

  async createCreator(creator: InsertCreator): Promise<Creator> {
    const newCreator: Creator = {
      id: nanoid(),
      userId: creator.userId || null,
      stageName: creator.stageName,
      bio: creator.bio || null,
      socialProfiles: creator.socialProfiles || null,
      paymentProfile: creator.paymentProfile ? {
        kycStatus: "pending" as const,
        paymentMethods: []
      } : null,
      specialties: creator.specialties || null,
      averageRate: creator.averageRate || null,
      totalEarnings: "0",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.creators.set(newCreator.id, newCreator);
    return newCreator;
  }

  async getCreator(id: string): Promise<Creator | undefined> {
    return this.creators.get(id);
  }

  async getCreatorByUserId(userId: string): Promise<Creator | undefined> {
    return Array.from(this.creators.values()).find(c => c.userId === userId);
  }

  async getCreators(accountId?: string): Promise<Creator[]> {
    // For MVP, return all creators
    return Array.from(this.creators.values());
  }

  async updateCreatorEarnings(creatorId: string, amount: number): Promise<void> {
    const creator = this.creators.get(creatorId);
    if (creator) {
      creator.totalEarnings = amount.toString();
      this.creators.set(creatorId, creator);
    }
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const newCampaign: Campaign = {
      id: nanoid(),
      name: campaign.name,
      accountId: campaign.accountId,
      description: campaign.description || null,
      status: campaign.status || "draft",
      startDate: campaign.startDate || null,
      endDate: campaign.endDate || null,
      budget: campaign.budget || null,
      targetAudience: campaign.targetAudience || null,
      marginGoal: "0",
      brandGuidelines: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.campaigns.set(newCampaign.id, newCampaign);
    return newCampaign;
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async getCampaigns(accountId: string): Promise<Campaign[]> {
    return Array.from(this.campaigns.values()).filter(c => c.accountId === accountId);
  }

  async updateCampaignStatus(id: string, status: string): Promise<void> {
    const campaign = this.campaigns.get(id);
    if (campaign) {
      campaign.status = status as any;
      this.campaigns.set(id, campaign);
    }
  }

  async createDeliverable(deliverable: InsertDeliverable): Promise<Deliverable> {
    const newDeliverable: Deliverable = {
      id: nanoid(),
      title: deliverable.title,
      type: deliverable.type,
      campaignId: deliverable.campaignId,
      creatorId: deliverable.creatorId,
      description: deliverable.description || null,
      requirements: deliverable.requirements ? {
        hashtags: [],
        mentions: [],
        deliveryFormat: "video"
      } : null,
      status: deliverable.status || "draft",
      dueDate: deliverable.dueDate || null,
      submittedAt: null,
      approvedAt: null,
      fee: "0",
      paymentStatus: null,
      notes: null,
      paymentRules: deliverable.paymentRules ? {
        milestones: []
      } : null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.deliverables.set(newDeliverable.id, newDeliverable);
    return newDeliverable;
  }

  async getDeliverable(id: string): Promise<Deliverable | undefined> {
    return this.deliverables.get(id);
  }

  async getDeliverables(filters?: {
    campaignId?: string;
    creatorId?: string;
    status?: string;
  }): Promise<Deliverable[]> {
    let result = Array.from(this.deliverables.values());
    if (filters?.campaignId) {
      result = result.filter(d => d.campaignId === filters.campaignId);
    }
    return result;
  }

  async updateDeliverableStatus(id: string, status: string, data?: any): Promise<void> {
    const deliverable = this.deliverables.get(id);
    if (deliverable) {
      deliverable.status = status as any;
      this.deliverables.set(id, deliverable);
    }
  }

  async createMetric(metric: InsertMetric): Promise<Metric> {
    const newMetric: Metric = {
      id: nanoid(),
      platform: metric.platform,
      deliverableId: metric.deliverableId,
      socialPostId: metric.socialPostId || null,
      views: metric.views || null,
      likes: metric.likes || null,
      comments: metric.comments || null,
      shares: metric.shares || null,
      saves: metric.saves || null,
      conversions: metric.conversions || null,
      revenue: metric.revenue || null,
      engagementRate: "0",
      clickThroughs: metric.clickThroughs || null,
      timestamp: new Date(),
    };
    this.metrics.set(newMetric.id, newMetric);
    return newMetric;
  }

  async getMetrics(deliverableId: string): Promise<Metric[]> {
    return Array.from(this.metrics.values()).filter(m => m.deliverableId === deliverableId);
  }

  async getCampaignMetrics(campaignId: string): Promise<Metric[]> {
    return [];
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const newInvoice: Invoice = {
      id: nanoid(),
      campaignId: invoice.campaignId,
      invoiceNumber: invoice.invoiceNumber,
      amount: invoice.amount,
      status: invoice.status || "draft",
      creatorId: invoice.creatorId || null,
      dueDate: invoice.dueDate || null,
      paidAt: null,
      stripeInvoiceId: null,
      notes: null,
      taxAmount: null,
      totalAmount: invoice.amount,
      splits: invoice.splits || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.invoices.set(newInvoice.id, newInvoice);
    return newInvoice;
  }

  async getInvoice(id: string): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async getInvoices(filters?: {
    campaignId?: string;
    creatorId?: string;
    status?: string;
  }): Promise<Invoice[]> {
    let result = Array.from(this.invoices.values());
    if (filters?.campaignId) {
      result = result.filter(i => i.campaignId === filters.campaignId);
    }
    return result;
  }

  async updateInvoiceStatus(id: string, status: string, paidAt?: Date): Promise<void> {
    const invoice = this.invoices.get(id);
    if (invoice) {
      invoice.status = status as any;
      invoice.paidAt = paidAt || null;
      this.invoices.set(id, invoice);
    }
  }

  async addPoints(userId: string, delta: number, reason: string, description?: string): Promise<PointsLog> {
    const pointsLog: PointsLog = {
      id: nanoid(),
      userId,
      delta,
      reason,
      description: description || null,
      relatedEntityType: null,
      relatedEntityId: null,
      createdAt: new Date(),
    };
    this.pointsLogs.set(pointsLog.id, pointsLog);
    return pointsLog;
  }

  async getUserPoints(userId: string): Promise<number> {
    const user = this.users.get(userId);
    return user?.points || 0;
  }

  async getPointsLogs(userId: string): Promise<PointsLog[]> {
    return Array.from(this.pointsLogs.values()).filter(p => p.userId === userId);
  }

  async updateUserTier(userId: string): Promise<void> {
    // MVP: do nothing
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const newNotification: Notification = {
      id: nanoid(),
      userId: notification.userId,
      title: notification.title,
      message: notification.message,
      type: notification.type,
      data: notification.data || null,
      read: false,
      createdAt: new Date(),
    };
    this.notifications.set(newNotification.id, newNotification);
    return newNotification;
  }

  async getUserNotifications(userId: string, unreadOnly?: boolean): Promise<Notification[]> {
    let result = Array.from(this.notifications.values()).filter(n => n.userId === userId);
    if (unreadOnly) {
      result = result.filter(n => !n.read);
    }
    return result;
  }

  async markNotificationRead(id: string): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.read = true;
      this.notifications.set(id, notification);
    }
  }

  async getDashboardMetrics(accountId: string): Promise<{
    totalSpend: number;
    totalViews: number;
    totalCreators: number;
    averageROI: number;
  }> {
    return {
      totalSpend: 0,
      totalViews: 0,
      totalCreators: this.creators.size,
      averageROI: 0,
    };
  }

  async getTopCreators(accountId: string, limit = 10): Promise<Creator[]> {
    return Array.from(this.creators.values()).slice(0, limit);
  }

  async updateUserRole(userId: string, role: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;

    user.role = role as "owner" | "manager" | "creator" | "viewer";
    user.updatedAt = new Date();
    this.users.set(userId, user);
    return user;
  }
}

export const storage = new MemStorage();