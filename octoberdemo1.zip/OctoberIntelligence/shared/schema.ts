import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  uuid,
  integer,
  decimal,
  boolean,
  primaryKey,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  accountId: uuid("account_id").references(() => accounts.id),
  role: varchar("role", { enum: ["owner", "manager", "creator", "viewer"] }).notNull().default("viewer"),
  points: integer("points").default(0),
  tier: varchar("tier", { enum: ["silver", "gold", "platinum"] }).default("silver"),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeConnectAccountId: varchar("stripe_connect_account_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const accounts = pgTable("accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name").notNull(),
  type: varchar("type", { enum: ["brand", "agency"] }).notNull(),
  stripeAccountId: varchar("stripe_account_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const creators = pgTable("creators", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").references(() => users.id),
  stageName: varchar("stage_name").notNull(),
  bio: text("bio"),
  socialProfiles: jsonb("social_profiles").$type<{
    platform: string;
    username: string;
    followersCount: number;
    verificationStatus: boolean;
  }[]>(),
  paymentProfile: jsonb("payment_profile").$type<{
    taxDocumentUrl?: string;
    kycStatus: "pending" | "verified" | "rejected";
    paymentMethods: string[];
  }>(),
  specialties: jsonb("specialties").$type<string[]>(),
  averageRate: decimal("average_rate", { precision: 10, scale: 2 }),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).default("0"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const campaigns = pgTable("campaigns", {
  id: uuid("id").primaryKey().defaultRandom(),
  accountId: uuid("account_id").references(() => accounts.id).notNull(),
  name: varchar("name").notNull(),
  description: text("description"),
  status: varchar("status", { 
    enum: ["draft", "active", "paused", "completed", "cancelled"] 
  }).default("draft"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  budget: decimal("budget", { precision: 10, scale: 2 }),
  marginGoal: decimal("margin_goal", { precision: 5, scale: 2 }),
  brandGuidelines: text("brand_guidelines"),
  targetAudience: jsonb("target_audience").$type<{
    demographics: string[];
    interests: string[];
    locations: string[];
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const deliverables = pgTable("deliverables", {
  id: uuid("id").primaryKey().defaultRandom(),
  campaignId: uuid("campaign_id").references(() => campaigns.id).notNull(),
  creatorId: uuid("creator_id").references(() => creators.id).notNull(),
  type: varchar("type", { 
    enum: ["youtube_video", "instagram_post", "instagram_story", "tiktok_video", "twitter_post"] 
  }).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  requirements: jsonb("requirements").$type<{
    duration?: number;
    hashtags: string[];
    mentions: string[];
    deliveryFormat: string;
  }>(),
  status: varchar("status", { 
    enum: ["brief", "draft", "approved", "live", "paid"] 
  }).default("brief"),
  dueDate: timestamp("due_date"),
  submittedAt: timestamp("submitted_at"),
  approvedAt: timestamp("approved_at"),
  publishedAt: timestamp("published_at"),
  contentUrl: varchar("content_url"),
  socialPostUrl: varchar("social_post_url"),
  amountDue: decimal("amount_due", { precision: 10, scale: 2 }),
  paymentRules: jsonb("payment_rules").$type<{
    milestones: {
      trigger: string;
      percentage: number;
      description: string;
    }[];
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const metrics = pgTable("metrics", {
  id: uuid("id").primaryKey().defaultRandom(),
  deliverableId: uuid("deliverable_id").references(() => deliverables.id).notNull(),
  platform: varchar("platform").notNull(),
  socialPostId: varchar("social_post_id"),
  views: integer("views").default(0),
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
  shares: integer("shares").default(0),
  saves: integer("saves").default(0),
  clickThroughs: integer("click_throughs").default(0),
  conversions: integer("conversions").default(0),
  revenue: decimal("revenue", { precision: 10, scale: 2 }).default("0"),
  engagementRate: decimal("engagement_rate", { precision: 5, scale: 4 }),
  timestamp: timestamp("timestamp").defaultNow(),
}, (table) => [
  index("idx_metrics_deliverable").on(table.deliverableId),
  index("idx_metrics_timestamp").on(table.timestamp),
]);

export const invoices = pgTable("invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  campaignId: uuid("campaign_id").references(() => campaigns.id).notNull(),
  creatorId: uuid("creator_id").references(() => creators.id),
  invoiceNumber: varchar("invoice_number").unique().notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  platformFee: decimal("platform_fee", { precision: 10, scale: 2 }).default("0"),
  creatorPayout: decimal("creator_payout", { precision: 10, scale: 2 }),
  status: varchar("status", { 
    enum: ["draft", "pending", "paid", "failed", "cancelled"] 
  }).default("draft"),
  dueDate: timestamp("due_date"),
  paidAt: timestamp("paid_at"),
  pdfUrl: varchar("pdf_url"),
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  splits: jsonb("splits").$type<{
    recipientId: string;
    amount: number;
    type: "creator" | "agency" | "platform";
  }[]>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const pointsLogs = pgTable("points_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  delta: integer("delta").notNull(),
  reason: varchar("reason").notNull(),
  description: text("description"),
  relatedEntityType: varchar("related_entity_type"),
  relatedEntityId: uuid("related_entity_id"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_points_logs_user").on(table.userId),
  index("idx_points_logs_created").on(table.createdAt),
]);

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: varchar("type").notNull(),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  data: jsonb("data"),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_notifications_user").on(table.userId),
  index("idx_notifications_read").on(table.read),
]);

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  account: one(accounts, {
    fields: [users.accountId],
    references: [accounts.id],
  }),
  creator: one(creators, {
    fields: [users.id],
    references: [creators.userId],
  }),
  pointsLogs: many(pointsLogs),
  notifications: many(notifications),
}));

export const accountsRelations = relations(accounts, ({ many }) => ({
  users: many(users),
  campaigns: many(campaigns),
}));

export const creatorsRelations = relations(creators, ({ one, many }) => ({
  user: one(users, {
    fields: [creators.userId],
    references: [users.id],
  }),
  deliverables: many(deliverables),
  invoices: many(invoices),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  account: one(accounts, {
    fields: [campaigns.accountId],
    references: [accounts.id],
  }),
  deliverables: many(deliverables),
  invoices: many(invoices),
}));

export const deliverablesRelations = relations(deliverables, ({ one, many }) => ({
  campaign: one(campaigns, {
    fields: [deliverables.campaignId],
    references: [campaigns.id],
  }),
  creator: one(creators, {
    fields: [deliverables.creatorId],
    references: [creators.id],
  }),
  metrics: many(metrics),
}));

export const metricsRelations = relations(metrics, ({ one }) => ({
  deliverable: one(deliverables, {
    fields: [metrics.deliverableId],
    references: [deliverables.id],
  }),
}));

export const invoicesRelations = relations(invoices, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [invoices.campaignId],
    references: [campaigns.id],
  }),
  creator: one(creators, {
    fields: [invoices.creatorId],
    references: [creators.id],
  }),
}));

export const pointsLogsRelations = relations(pointsLogs, ({ one }) => ({
  user: one(users, {
    fields: [pointsLogs.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCreatorSchema = createInsertSchema(creators).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDeliverableSchema = createInsertSchema(deliverables).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMetricSchema = createInsertSchema(metrics).omit({
  id: true,
  timestamp: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPointsLogSchema = createInsertSchema(pointsLogs).omit({
  id: true,
  createdAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Creator = typeof creators.$inferSelect;
export type InsertCreator = z.infer<typeof insertCreatorSchema>;
export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Deliverable = typeof deliverables.$inferSelect;
export type InsertDeliverable = z.infer<typeof insertDeliverableSchema>;
export type Metric = typeof metrics.$inferSelect;
export type InsertMetric = z.infer<typeof insertMetricSchema>;
export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type PointsLog = typeof pointsLogs.$inferSelect;
export type InsertPointsLog = z.infer<typeof insertPointsLogSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
