# October - Premium Influencer Marketing Platform

## Overview

October is a premium SaaS platform for influencer marketing that brings together brands, agencies, and creators with AI-powered tools, real-time collaboration, and gamified experiences. The platform features a modern, award-winning design aesthetic with Bauhaus-inspired minimalism, leveraging a sophisticated tech stack for enterprise-grade performance.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript and Vite for fast development and builds
- **Styling**: Tailwind CSS with custom design system (gold #C9A86A, charcoal #111111, white #FFFFFF)
- **Component Library**: Radix UI components via shadcn/ui for accessible, customizable components
- **State Management**: TanStack Query for server state, Zustand for client state
- **Routing**: Wouter for lightweight client-side routing
- **Typography**: Inter (body text), Playfair Display (headings)
- **Animations**: Framer Motion for smooth 250ms transitions

### Backend Architecture
- **Runtime**: Node.js with Express server
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Authentication**: Replit Auth integration with session management
- **Real-time**: WebSocket implementation for live updates
- **API**: RESTful endpoints with structured routing

### Design System
- **Grid**: 12-column CSS grid layout
- **Breakpoints**: 640px, 768px, 1024px, 1280px, 1536px
- **Border Radius**: 2xl (1rem) for modern rounded corners
- **Color Scheme**: CSS variables supporting light/dark mode auto-switching
- **Icons**: Lucide React icon set

## Key Components

### Database Schema
- **Users**: Replit auth integration with roles (owner, manager, creator, viewer)
- **Accounts**: Brand/agency organizations with Stripe integration
- **Creators**: Content creator profiles with social platforms and payment data
- **Campaigns**: Marketing campaigns with budget and timeline management
- **Deliverables**: Individual content pieces with status tracking
- **Metrics**: Performance analytics and engagement data
- **Invoices**: Payment processing and financial tracking
- **Points/Notifications**: Gamification and real-time updates

### Core Features
1. **Unified Campaign Board**: Kanban-style interface with drag-drop functionality
2. **Creator Network**: Discovery and management of creator partnerships
3. **Analytics Dashboard**: Real-time metrics and ROI tracking
4. **AI Assistants**: Creator matching, brief generation, rate recommendations
5. **Payment System**: Stripe-powered payment processing and invoicing
6. **Gamification**: Points system with tier progression (Silver, Gold, Platinum)

### Authentication & Authorization
- Replit-based authentication with OpenID Connect
- Role-based access control (RBAC)
- Session management with PostgreSQL store
- JWT token handling for API security

## Data Flow

1. **User Authentication**: Replit OAuth → Session creation → Role assignment
2. **Campaign Management**: Create campaigns → Add deliverables → Track progress → Process payments
3. **Real-time Updates**: WebSocket connections → Live status updates → Optimistic UI updates
4. **Analytics**: Metric collection → Data aggregation → Dashboard visualization
5. **AI Integration**: OpenAI API → Creator matching/brief generation → Rate recommendations

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL with connection pooling
- **Authentication**: Replit Auth with OpenID Connect
- **Payments**: Stripe Connect for split payments
- **AI Services**: OpenAI GPT-4 for AI assistants
- **File Storage**: Planned integration for document management

### Development Tools
- **Build**: Vite with TypeScript support
- **Database**: Drizzle Kit for migrations and schema management
- **Styling**: PostCSS with Tailwind CSS
- **Development**: Hot module replacement and error overlay

### UI/UX Libraries
- **Components**: Radix UI primitives
- **Charts**: Recharts for analytics visualization
- **Forms**: React Hook Form with Zod validation
- **Animations**: CSS transitions with hover effects and ripple interactions

## Deployment Strategy

### Development Environment
- Replit-based development with hot reloading
- Environment variable management for database and API keys
- Development server with Express and Vite integration

### Production Considerations
- Node.js server with Express
- PostgreSQL database connection pooling
- Static asset serving via Vite build
- WebSocket server for real-time features

### Build Process
- TypeScript compilation and bundling
- Frontend build with Vite
- Backend bundle with esbuild
- Database migrations via Drizzle Kit

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 08, 2025. Initial setup
- July 08, 2025. Implemented role-based access control with different dashboard views for agency owners, brand managers, and content creators. Added role switcher component for demo purposes.
- July 08, 2025. Updated viewer name to "Moe Sarue" and implemented comprehensive visual gamification system with points display, achievement badges, leaderboard, and tier progression across all role dashboards. Fixed text alignment issues in dashboard headers.
- July 14, 2025. Removed authentication system completely for pure product demonstration. App now opens directly to dashboard without login flow. Created mock user system with demo data. Removed profile picture from mock user data.