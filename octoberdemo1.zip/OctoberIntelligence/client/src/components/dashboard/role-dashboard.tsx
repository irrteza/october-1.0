import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import MetricsOverview from "./metrics-overview";
import TopCreators from "./top-creators";
import CampaignBoard from "./campaign-board";
import PointsDisplay from "../gamification/points-display";
import Achievements from "../gamification/achievements";
import Leaderboard from "../gamification/leaderboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Briefcase, Target, Wallet } from "lucide-react";

// Global state for role switching
let currentRole = "owner";
const roleListeners: ((role: string) => void)[] = [];

export function setCurrentRole(role: string) {
  currentRole = role;
  roleListeners.forEach(listener => listener(role));
}

export function useCurrentRole() {
  const [role, setRole] = useState(currentRole);
  
  useEffect(() => {
    const listener = (newRole: string) => setRole(newRole);
    roleListeners.push(listener);
    return () => {
      const index = roleListeners.indexOf(listener);
      if (index > -1) roleListeners.splice(index, 1);
    };
  }, []);
  
  return role;
}

// Agency Dashboard - Full campaign management view
function AgencyDashboard() {
  return (
    <div className="space-y-6">
      <div className="max-w-full">
        <h1 className="text-3xl font-bold text-foreground mb-2 break-words">Agency Dashboard</h1>
        <p className="text-muted-foreground break-words">Full campaign management and creator partnerships</p>
      </div>
      
      <MetricsOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <CampaignBoard />
        </div>
        <div className="space-y-6">
          <PointsDisplay />
          <TopCreators />
          <Card className="hover-glow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-gold" />
                <span>Quick Actions</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full">Create New Campaign</Button>
              <Button variant="outline" className="w-full">Find Creators</Button>
              <Button variant="outline" className="w-full">View Analytics</Button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <Achievements />
        <Leaderboard />
      </div>
    </div>
  );
}

// Brand Dashboard - Simplified campaign view focused on results
function BrandDashboard() {
  return (
    <div className="space-y-6">
      <div className="max-w-full">
        <h1 className="text-3xl font-bold text-foreground mb-2 break-words">Brand Dashboard</h1>
        <p className="text-muted-foreground break-words">Track your brand's influencer campaigns</p>
      </div>
      
      <MetricsOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <PointsDisplay />
        <Card className="hover-glow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-gold" />
              <span>Active Campaigns</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border rounded-2xl">
                <div>
                  <h3 className="font-medium">Spring Fashion Collection</h3>
                  <p className="text-sm text-muted-foreground">4 deliverables in progress</p>
                </div>
                <Badge variant="outline" className="text-gold border-gold/20">Active</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        <TopCreators />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <Achievements />
        <Leaderboard />
      </div>
      
      <CampaignBoard />
    </div>
  );
}

// Creator Dashboard - Personal earnings and deliverable tracking
function CreatorDashboard() {
  return (
    <div className="space-y-6">
      <div className="max-w-full">
        <h1 className="text-3xl font-bold text-foreground mb-2 break-words">Creator Dashboard</h1>
        <p className="text-muted-foreground break-words">Track your earnings and deliverables</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <PointsDisplay />
        <Card className="hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gold/10 rounded-full">
                <Wallet className="w-6 h-6 text-gold" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Earnings</p>
                <p className="text-2xl font-bold text-foreground">$12,500</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gold/10 rounded-full">
                <Target className="w-6 h-6 text-gold" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Deliverables</p>
                <p className="text-2xl font-bold text-foreground">8 Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gold/10 rounded-full">
                <Briefcase className="w-6 h-6 text-gold" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Campaigns</p>
                <p className="text-2xl font-bold text-foreground">3 Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <Achievements />
        <Leaderboard />
      </div>
      
      <Card className="hover-glow">
        <CardHeader>
          <CardTitle>Your Deliverables</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border border-border rounded-2xl">
              <div>
                <h3 className="font-medium">Instagram Reel - Outfit Styling</h3>
                <p className="text-sm text-muted-foreground">Due: Feb 15, 2025</p>
              </div>
              <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20">
                In Progress
              </Badge>
            </div>
            <div className="flex items-center justify-between p-4 border border-border rounded-2xl">
              <div>
                <h3 className="font-medium">TikTok - Behind the Scenes</h3>
                <p className="text-sm text-muted-foreground">Due: Feb 20, 2025</p>
              </div>
              <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
                Approved
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Main component that renders based on user role
export default function RoleDashboard() {
  const { user } = useAuth();
  const role = useCurrentRole();
  
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }
  
  switch (role) {
    case "creator":
      return <CreatorDashboard />;
    case "manager":
      return <BrandDashboard />;
    case "owner":
    default:
      return <AgencyDashboard />;
  }
}