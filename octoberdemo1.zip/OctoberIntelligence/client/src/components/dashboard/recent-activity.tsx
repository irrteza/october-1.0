import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, DollarSign, Plus } from "lucide-react";
import { format } from "date-fns";

export default function RecentActivity() {
  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["/api/notifications"],
  });

  // Mock recent activity if no notifications
  const mockActivities = [
    {
      id: "1",
      type: "deliverable_completed",
      title: "Sarah Chen completed deliverable for Summer Fashion Campaign",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      icon: CheckCircle,
      iconColor: "text-green-600",
      iconBg: "bg-green-100"
    },
    {
      id: "2", 
      type: "payment_processed",
      title: "Payment of $2,500 processed to Mike Torres",
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      icon: DollarSign,
      iconColor: "text-gold",
      iconBg: "bg-gold bg-opacity-20"
    },
    {
      id: "3",
      type: "campaign_created",
      title: "New campaign \"Holiday Collection\" created",
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      icon: Plus,
      iconColor: "text-blue-600",
      iconBg: "bg-blue-100"
    }
  ];

  const activities = notifications.length > 0 ? notifications.slice(0, 5) : mockActivities;

  if (isLoading) {
    return (
      <Card className="hover-glow">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse flex items-start space-x-3">
                <div className="w-8 h-8 bg-muted rounded-full flex-shrink-0"></div>
                <div className="flex-1">
                  <div className="h-4 bg-muted rounded w-full mb-2"></div>
                  <div className="h-3 bg-muted rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover-glow">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity: any, index: number) => {
            const Icon = activity.icon || CheckCircle;
            return (
              <div 
                key={activity.id} 
                className="flex items-start space-x-3 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`w-8 h-8 ${activity.iconBg || 'bg-green-100'} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-4 h-4 ${activity.iconColor || 'text-green-600'}`} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-foreground">
                    {activity.title || activity.message}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {format(new Date(activity.timestamp || activity.createdAt), "h:mm a")}
                  </p>
                </div>
              </div>
            );
          })}
          
          {activities.length === 0 && (
            <div className="text-center py-6 text-muted-foreground">
              <p>No recent activity</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
