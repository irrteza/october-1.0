import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Filter, MoreHorizontal } from "lucide-react";
import KanbanLane from "@/components/kanban/kanban-lane";

export default function CampaignBoard() {
  const [selectedCampaign, setSelectedCampaign] = useState<string | null>(null);

  const { data: campaigns = [] } = useQuery({
    queryKey: ["/api/campaigns"],
  });

  const { data: deliverables = [] } = useQuery({
    queryKey: ["/api/deliverables", selectedCampaign],
    enabled: !!selectedCampaign,
  });

  const lanes = [
    { id: "brief", title: "Brief", status: "brief" },
    { id: "draft", title: "Draft", status: "draft" },
    { id: "approved", title: "Approved", status: "approved" },
    { id: "live", title: "Live", status: "live" },
    { id: "paid", title: "Paid", status: "paid" },
  ];

  const getDeliverablesForLane = (status: string) => {
    return deliverables.filter((d: any) => d.status === status);
  };

  // Auto-select first campaign if none selected
  if (!selectedCampaign && campaigns.length > 0) {
    setSelectedCampaign(campaigns[0].id);
  }

  return (
    <Card className="hover-glow">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Campaign Board</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="rounded-xl">
              <Filter className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="rounded-xl">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Campaign Selector */}
        {campaigns.length > 1 && (
          <div className="mb-6">
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {campaigns.slice(0, 3).map((campaign: any) => (
                <Button
                  key={campaign.id}
                  variant={selectedCampaign === campaign.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCampaign(campaign.id)}
                  className="rounded-2xl whitespace-nowrap"
                >
                  {campaign.name}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Kanban Board */}
        {selectedCampaign ? (
          <div className="grid grid-cols-5 gap-4 min-h-96 overflow-x-auto">
            {lanes.map((lane) => (
              <KanbanLane
                key={lane.id}
                title={lane.title}
                status={lane.status}
                deliverables={getDeliverablesForLane(lane.status)}
                campaignId={selectedCampaign}
              />
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">No Campaigns</h3>
              <p>Create your first campaign to get started</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
