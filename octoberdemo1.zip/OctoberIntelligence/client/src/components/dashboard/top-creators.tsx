import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TrendingUp } from "lucide-react";
import { Link } from "wouter";

export default function TopCreators() {
  const { data: topCreators = [], isLoading } = useQuery({
    queryKey: ["/api/creators/top", { limit: 5 }],
  });

  if (isLoading) {
    return (
      <Card className="hover-glow">
        <CardHeader>
          <CardTitle>Top Creators</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse flex items-center space-x-3">
                <div className="w-10 h-10 bg-muted rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover-glow">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Top Creators</CardTitle>
          <Link href="/creators">
            <Button variant="ghost" size="sm" className="text-gold hover:text-gold/90">
              View All
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topCreators.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              <p>No creators data available</p>
            </div>
          ) : (
            topCreators.map((creator: any, index: number) => (
              <div 
                key={creator.id} 
                className="flex items-center justify-between animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${creator.stageName}`} />
                    <AvatarFallback>{creator.stageName?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-foreground">{creator.stageName}</div>
                    <div className="text-sm text-muted-foreground">
                      @{creator.stageName?.toLowerCase().replace(/\s+/g, '')}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-foreground">
                    ${parseFloat(creator.totalEarnings || '0').toLocaleString()}
                  </div>
                  <div className="text-sm text-green-600 flex items-center">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +{Math.floor(Math.random() * 30 + 10)}%
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
