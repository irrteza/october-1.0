import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Edit3, Calculator } from "lucide-react";
import { Link } from "wouter";

export default function AIAssistants() {
  const assistants = [
    {
      name: "Creator Match",
      description: "Find similar creators to top performers",
      icon: Search,
      gradient: "from-purple-50 to-blue-50",
      iconColor: "text-purple-600"
    },
    {
      name: "Brief Copilot",
      description: "Generate content briefs from product URLs",
      icon: Edit3,
      gradient: "from-green-50 to-emerald-50",
      iconColor: "text-green-600"
    },
    {
      name: "Rate Advisor",
      description: "AI-powered pricing recommendations",
      icon: Calculator,
      gradient: "from-gold to-yellow-50",
      iconColor: "text-gold"
    }
  ];

  return (
    <Card className="hover-glow">
      <CardHeader>
        <CardTitle>AI Assistants</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {assistants.map((assistant, index) => {
            const Icon = assistant.icon;
            return (
              <Link key={assistant.name} href="/ai-assistants">
                <div className={`p-4 bg-gradient-to-r ${assistant.gradient} rounded-2xl hover-glow cursor-pointer animate-slide-up`} 
                     style={{ animationDelay: `${index * 100}ms` }}>
                  <div className="flex items-center mb-2">
                    <Icon className={`w-5 h-5 ${assistant.iconColor} mr-3`} />
                    <span className="font-medium">{assistant.name}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{assistant.description}</p>
                </div>
              </Link>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
