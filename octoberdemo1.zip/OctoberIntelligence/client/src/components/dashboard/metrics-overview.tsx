import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, Eye, TrendingUp, Users } from "lucide-react";

export default function MetricsOverview() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const metricCards = [
    {
      title: "Total Spend",
      value: `$${metrics?.totalSpend?.toLocaleString() || '0'}`,
      change: "+12.5% from last month",
      icon: DollarSign,
      iconBg: "bg-gold bg-opacity-10",
      iconColor: "text-gold",
      changeColor: "text-green-600"
    },
    {
      title: "Total Views",
      value: `${metrics?.totalViews?.toLocaleString() || '0'}`,
      change: "+8.3% from last month",
      icon: Eye,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      changeColor: "text-green-600"
    },
    {
      title: "ROI",
      value: `${metrics?.averageROI?.toFixed(1) || '0'}x`,
      change: "+0.8x from last month",
      icon: TrendingUp,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      changeColor: "text-green-600"
    },
    {
      title: "Active Creators",
      value: `${metrics?.totalCreators || '0'}`,
      change: "5 new this month",
      icon: Users,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      changeColor: "text-blue-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in">
      {metricCards.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card key={index} className="hover-glow animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                  <p className="text-3xl font-bold text-foreground mt-2">{metric.value}</p>
                  <p className={`text-sm mt-1 ${metric.changeColor}`}>{metric.change}</p>
                </div>
                <div className={`w-12 h-12 ${metric.iconBg} rounded-2xl flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${metric.iconColor}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
