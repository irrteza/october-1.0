import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MoreHorizontal } from "lucide-react";
import { format } from "date-fns";

interface KanbanCardProps {
  deliverable: any;
  index: number;
}

export default function KanbanCard({ deliverable, index }: KanbanCardProps) {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("text/plain", deliverable.id);
  };

  const getPlatformColor = (type: string) => {
    const colors: Record<string, string> = {
      youtube_video: "bg-red-100 text-red-600",
      instagram_post: "bg-pink-100 text-pink-600",
      instagram_story: "bg-purple-100 text-purple-600",
      tiktok_video: "bg-gray-100 text-gray-700",
      twitter_post: "bg-blue-100 text-blue-600"
    };
    return colors[type] || "bg-gray-100 text-gray-700";
  };

  const getPlatformName = (type: string) => {
    const names: Record<string, string> = {
      youtube_video: "YouTube",
      instagram_post: "Instagram",
      instagram_story: "Stories",
      tiktok_video: "TikTok",
      twitter_post: "Twitter"
    };
    return names[type] || type;
  };

  const getStatusStyle = (status: string) => {
    const styles: Record<string, string> = {
      brief: "bg-light-gray dark:bg-muted",
      draft: "bg-light-gray dark:bg-muted",
      approved: "bg-green-50 border-green-200",
      live: "bg-blue-50 border-blue-200",
      paid: "bg-gold bg-opacity-10 border-gold border-opacity-30"
    };
    return styles[status] || "bg-light-gray dark:bg-muted";
  };

  return (
    <div 
      draggable
      onDragStart={handleDragStart}
      className={`kanban-card ${getStatusStyle(deliverable.status)} rounded-2xl p-4 cursor-pointer animate-slide-up border`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="flex items-center justify-between mb-2">
        <Badge className={`text-xs ${getPlatformColor(deliverable.type)}`}>
          {getPlatformName(deliverable.type)}
        </Badge>
        <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
      </div>
      
      <h4 className="font-medium text-foreground mb-2">{deliverable.title}</h4>
      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
        {deliverable.description || "No description provided"}
      </p>
      
      <div className="flex items-center justify-between">
        <Avatar className="w-6 h-6">
          <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${deliverable.creatorId}`} />
          <AvatarFallback className="text-xs">C</AvatarFallback>
        </Avatar>
        
        <div className="text-xs text-muted-foreground">
          {deliverable.dueDate ? (
            <span>Due: {format(new Date(deliverable.dueDate), "MMM dd")}</span>
          ) : deliverable.status === "live" ? (
            <span className="text-blue-600">Live</span>
          ) : deliverable.status === "paid" ? (
            <span className="text-gold">${deliverable.amountDue || '0'}</span>
          ) : (
            <span>In Progress</span>
          )}
        </div>
      </div>
    </div>
  );
}
