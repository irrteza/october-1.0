import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Badge } from "@/components/ui/badge";
import KanbanCard from "./kanban-card";

interface KanbanLaneProps {
  title: string;
  status: string;
  deliverables: any[];
  campaignId: string;
}

export default function KanbanLane({ title, status, deliverables, campaignId }: KanbanLaneProps) {
  const queryClient = useQueryClient();
  const { updateDeliverable } = useWebSocket();

  const updateStatusMutation = useMutation({
    mutationFn: async ({ deliverableId, newStatus }: { deliverableId: string; newStatus: string }) => {
      await apiRequest("PATCH", `/api/deliverables/${deliverableId}/status`, { status: newStatus });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/deliverables"] });
    }
  });

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const deliverableId = e.dataTransfer.getData("text/plain");
    
    if (deliverableId) {
      updateStatusMutation.mutate({ deliverableId, newStatus: status });
      updateDeliverable(deliverableId, { status }, campaignId);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      brief: "bg-gray-100 text-gray-700",
      draft: "bg-blue-100 text-blue-700",
      approved: "bg-green-100 text-green-700",
      live: "bg-purple-100 text-purple-700",
      paid: "bg-gold bg-opacity-20 text-gold"
    };
    return colors[status] || "bg-gray-100 text-gray-700";
  };

  return (
    <div className="min-w-64">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-muted-foreground">{title}</h3>
        <Badge className={getStatusColor(status)}>
          {deliverables.length}
        </Badge>
      </div>
      
      <div 
        className="space-y-3 min-h-32 p-2 rounded-2xl border-2 border-dashed border-transparent transition-colors"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        style={{
          borderColor: "transparent"
        }}
        onDragEnter={(e) => {
          e.currentTarget.style.borderColor = "hsl(37, 35%, 60%)";
          e.currentTarget.style.backgroundColor = "hsl(37, 35%, 60%, 0.05)";
        }}
        onDragLeave={(e) => {
          e.currentTarget.style.borderColor = "transparent";
          e.currentTarget.style.backgroundColor = "transparent";
        }}
      >
        {deliverables.map((deliverable, index) => (
          <KanbanCard 
            key={deliverable.id} 
            deliverable={deliverable}
            index={index}
          />
        ))}
        
        {deliverables.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-sm">No items</p>
          </div>
        )}
      </div>
    </div>
  );
}
