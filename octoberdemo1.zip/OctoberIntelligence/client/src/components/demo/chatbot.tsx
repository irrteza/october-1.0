import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Send, Bot, User, TrendingUp, Users, DollarSign, Calendar } from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
  suggestions?: string[];
}

const demoResponses = {
  "campaign performance": {
    text: "Based on your active campaigns, here's the performance summary:\n\n📊 **Spring Fashion Collection**: 2.4M views, 3.2% engagement\n🎯 **Summer Lifestyle**: 1.8M views, 4.1% engagement\n💰 **Total ROI**: 312% across all campaigns\n\n**Top performing content**: Instagram Reels are driving 65% more engagement than static posts.",
    suggestions: ["Show detailed metrics", "Compare with last month", "Export campaign report"]
  },
  "analytics": {
    text: "Here are your key analytics insights:\n\n📈 **This Month**: $45,000 spent, 8.2M total reach\n🎯 **Best Performing Creators**: StyleByEmma (4.2% avg. engagement)\n💡 **Optimization Tip**: Tuesday posts get 23% more engagement\n\n**Trending hashtags**: #SustainableFashion, #OOTD, #SummerVibes",
    suggestions: ["View full analytics dashboard", "Download monthly report", "Set up automated alerts"]
  },
  "creators": {
    text: "Your creator network overview:\n\n👥 **Active Creators**: 12 creators across 5 campaigns\n⭐ **Top Performer**: StyleByEmma (Gold tier, 125K followers)\n🎯 **Engagement Rate**: 3.8% average across all creators\n\n**Available for new campaigns**: 4 creators ready to start",
    suggestions: ["Browse creator profiles", "Find similar creators", "Schedule creator calls"]
  },
  "budget": {
    text: "Campaign budget analysis:\n\n💰 **Total Budget**: $75,000 allocated\n📊 **Spent**: $45,000 (60% utilized)\n🎯 **Remaining**: $30,000 available\n\n**Budget by platform**:\n• Instagram: $28,000 (62%)\n• TikTok: $12,000 (27%)\n• YouTube: $5,000 (11%)",
    suggestions: ["Adjust campaign budgets", "View cost breakdown", "Set budget alerts"]
  }
};

const quickActions = [
  { icon: TrendingUp, label: "Campaign performance", key: "campaign performance" },
  { icon: Users, label: "Creator insights", key: "creators" },
  { icon: DollarSign, label: "Budget analysis", key: "budget" },
  { icon: Calendar, label: "Analytics overview", key: "analytics" }
];

export default function DemoChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your October AI assistant. I can help you with campaign insights, analytics, creator performance, and more. What would you like to know?",
      sender: "bot",
      timestamp: new Date(),
      suggestions: ["Campaign performance", "Analytics overview", "Creator insights", "Budget analysis"]
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const handleSend = (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");

    // Simulate AI response
    setTimeout(() => {
      const lowerText = text.toLowerCase();
      let response = demoResponses.analytics; // Default response

      if (lowerText.includes("campaign") || lowerText.includes("performance")) {
        response = demoResponses["campaign performance"];
      } else if (lowerText.includes("creator") || lowerText.includes("influencer")) {
        response = demoResponses.creators;
      } else if (lowerText.includes("budget") || lowerText.includes("cost") || lowerText.includes("spend")) {
        response = demoResponses.budget;
      } else if (lowerText.includes("analytics") || lowerText.includes("metrics") || lowerText.includes("data")) {
        response = demoResponses.analytics;
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text,
        sender: "bot",
        timestamp: new Date(),
        suggestions: response.suggestions
      };

      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const handleQuickAction = (key: string) => {
    handleSend(key);
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg bg-gold hover:bg-gold/90 z-50"
      >
        <MessageCircle className="h-6 w-6 text-white" />
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[500px] shadow-xl z-50 flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Bot className="h-5 w-5 text-gold" />
            <span className="text-lg">October AI</span>
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(false)}
            className="h-8 w-8 p-0"
          >
            ×
          </Button>
        </div>
        <Badge variant="secondary" className="w-fit">
          Demo Assistant
        </Badge>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-4 space-y-4">
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.sender === "user"
                      ? "bg-gold text-white"
                      : "bg-muted text-foreground"
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.sender === "bot" && (
                      <Bot className="h-4 w-4 mt-0.5 text-gold" />
                    )}
                    {message.sender === "user" && (
                      <User className="h-4 w-4 mt-0.5 text-white" />
                    )}
                    <div className="flex-1">
                      <p className="text-sm whitespace-pre-line">{message.text}</p>
                      {message.suggestions && (
                        <div className="mt-2 space-y-1">
                          {message.suggestions.map((suggestion, idx) => (
                            <Button
                              key={idx}
                              variant="outline"
                              size="sm"
                              className="text-xs h-6 mr-1"
                              onClick={() => handleSend(suggestion)}
                            >
                              {suggestion}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {quickActions.map((action) => (
              <Button
                key={action.key}
                variant="outline"
                size="sm"
                className="text-xs h-8 justify-start"
                onClick={() => handleQuickAction(action.key)}
              >
                <action.icon className="h-3 w-3 mr-1" />
                {action.label}
              </Button>
            ))}
          </div>

          <div className="flex space-x-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask about campaigns, analytics..."
              className="flex-1 text-sm"
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  handleSend(inputValue);
                }
              }}
            />
            <Button
              onClick={() => handleSend(inputValue)}
              className="bg-gold hover:bg-gold/90"
              size="sm"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}