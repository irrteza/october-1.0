import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Star, Trophy, Crown, Award } from "lucide-react";

const tierConfig = {
  silver: {
    name: "Silver",
    icon: Star,
    color: "bg-gray-500/10 text-gray-600 border-gray-500/20",
    nextTier: "Gold",
    pointsNeeded: 500,
    description: "Building your reputation"
  },
  gold: {
    name: "Gold", 
    icon: Trophy,
    color: "bg-gold/10 text-gold border-gold/20",
    nextTier: "Platinum",
    pointsNeeded: 1000,
    description: "Established influencer"
  },
  platinum: {
    name: "Platinum",
    icon: Crown,
    color: "bg-purple-500/10 text-purple-600 border-purple-500/20",
    nextTier: null,
    pointsNeeded: null,
    description: "Elite status achieved"
  }
};

export default function PointsDisplay() {
  const { user } = useAuth();
  
  if (!user) return null;

  const points = user.points || 0;
  const tier = user.tier || "silver";
  const config = tierConfig[tier as keyof typeof tierConfig];
  const Icon = config.icon;
  
  // Calculate progress to next tier
  let progress = 0;
  let pointsToNext = 0;
  
  if (config.pointsNeeded) {
    const currentTierStart = tier === "silver" ? 0 : tier === "gold" ? 500 : 1000;
    progress = ((points - currentTierStart) / (config.pointsNeeded - currentTierStart)) * 100;
    pointsToNext = config.pointsNeeded - points;
  } else {
    progress = 100; // Platinum is max tier
  }

  return (
    <Card className="hover-glow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gold/10 rounded-full">
              <Icon className="w-5 h-5 text-gold" />
            </div>
            <div>
              <Badge variant="outline" className={config.color}>
                {config.name} Tier
              </Badge>
              <p className="text-sm text-muted-foreground mt-1">{config.description}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-foreground">{points}</p>
            <p className="text-xs text-muted-foreground">Points</p>
          </div>
        </div>
        
        {config.nextTier && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progress to {config.nextTier}</span>
              <span className="text-muted-foreground">{pointsToNext} points to go</span>
            </div>
            <Progress value={Math.min(progress, 100)} className="h-2" />
          </div>
        )}
        
        {tier === "platinum" && (
          <div className="text-center py-2">
            <Award className="w-6 h-6 text-purple-600 mx-auto mb-1" />
            <p className="text-sm text-purple-600 font-medium">Maximum tier achieved!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}