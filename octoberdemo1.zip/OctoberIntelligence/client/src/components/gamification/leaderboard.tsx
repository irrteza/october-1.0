import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Crown, Trophy, Award, TrendingUp } from "lucide-react";

interface LeaderboardUser {
  id: string;
  name: string;
  avatar?: string;
  points: number;
  tier: "silver" | "gold" | "platinum";
  weeklyGain: number;
  rank: number;
}

const leaderboardData: LeaderboardUser[] = [
  {
    id: "1",
    name: "Moe Sarue",
    points: 750,
    tier: "gold",
    weeklyGain: 125,
    rank: 2
  },
  {
    id: "2", 
    name: "Sarah Chen",
    points: 1250,
    tier: "platinum",
    weeklyGain: 200,
    rank: 1
  },
  {
    id: "3",
    name: "Alex Rivera",
    points: 680,
    tier: "gold", 
    weeklyGain: 85,
    rank: 3
  },
  {
    id: "4",
    name: "Emma Thompson",
    points: 520,
    tier: "gold",
    weeklyGain: 95,
    rank: 4
  },
  {
    id: "5",
    name: "Marcus Johnson",
    points: 420,
    tier: "silver",
    weeklyGain: 60,
    rank: 5
  }
];

const tierIcons = {
  silver: Award,
  gold: Trophy,
  platinum: Crown
};

const tierColors = {
  silver: "text-gray-600",
  gold: "text-gold",
  platinum: "text-purple-600"
};

const rankColors = {
  1: "bg-gold/10 border-gold/20",
  2: "bg-gray-400/10 border-gray-400/20", 
  3: "bg-amber-600/10 border-amber-600/20"
};

export default function Leaderboard() {
  return (
    <Card className="hover-glow">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Trophy className="w-5 h-5 text-gold" />
          <span>Top Performers</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {leaderboardData.map((user) => {
          const TierIcon = tierIcons[user.tier];
          const isTopThree = user.rank <= 3;
          
          return (
            <div 
              key={user.id}
              className={`flex items-center space-x-3 p-3 rounded-2xl border transition-all ${
                isTopThree 
                  ? rankColors[user.rank as keyof typeof rankColors] || "bg-background border-border"
                  : "bg-background border-border"
              }`}
            >
              <div className="flex items-center space-x-3 flex-1">
                <div className="relative">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback className="bg-gold/10 text-gold font-medium">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  {user.rank === 1 && (
                    <div className="absolute -top-1 -right-1 bg-gold text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                      1
                    </div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium text-sm truncate">
                      {user.name}
                      {user.name === "Moe Sarue" && (
                        <span className="text-gold ml-1">(You)</span>
                      )}
                    </h4>
                    <TierIcon className={`w-3 h-3 ${tierColors[user.tier]}`} />
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>{user.points} points</span>
                    <div className="flex items-center space-x-1 text-green-600">
                      <TrendingUp className="w-3 h-3" />
                      <span>+{user.weeklyGain}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <Badge variant="outline" className={
                  user.rank === 1 ? "bg-gold/10 text-gold border-gold/20" :
                  user.rank === 2 ? "bg-gray-400/10 text-gray-600 border-gray-400/20" :
                  user.rank === 3 ? "bg-amber-600/10 text-amber-600 border-amber-600/20" :
                  "bg-muted border-border"
                }>
                  #{user.rank}
                </Badge>
              </div>
            </div>
          );
        })}
        
        <div className="pt-2 text-center">
          <p className="text-xs text-muted-foreground">
            Rankings updated weekly • Earn points by completing campaigns
          </p>
        </div>
      </CardContent>
    </Card>
  );
}