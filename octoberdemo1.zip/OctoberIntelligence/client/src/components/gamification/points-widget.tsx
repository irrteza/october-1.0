import { useQuery } from "@tanstack/react-query";
import { Crown, Trophy } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function PointsWidget() {
  const { data: pointsData, isLoading } = useQuery({
    queryKey: ["/api/points"],
  });

  if (isLoading) {
    return (
      <div className="p-3 mx-3 mb-6 bg-gradient-to-br from-gold to-yellow-600 rounded-2xl text-white animate-pulse">
        <div className="h-16 bg-white bg-opacity-20 rounded"></div>
      </div>
    );
  }

  const points = pointsData?.points || 0;
  const tier = getTier(points);
  const nextTier = getNextTier(tier);
  const progress = getTierProgress(points, tier);

  return (
    <div className="p-3 mx-3 mb-6 bg-gradient-to-br from-gold to-yellow-600 rounded-2xl text-white">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold">October Elite</span>
        <div className="w-6 h-6 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
          <Trophy className="w-4 h-4" />
        </div>
      </div>
      
      <div className="text-xs opacity-90 mb-2">
        {getTierDisplay(tier)} • {points.toLocaleString()} pts
      </div>
      
      <div className="w-full bg-white bg-opacity-20 rounded-full h-2 mb-2">
        <div 
          className="progress-bar h-2 rounded-full transition-all duration-500" 
          style={{ width: `${progress}%` }}
        />
      </div>
      
      <div className="text-xs opacity-90">
        {nextTier ? (
          `${getPointsToNextTier(points, tier)} pts to ${getTierDisplay(nextTier)}`
        ) : (
          "Maximum tier achieved!"
        )}
      </div>
    </div>
  );
}

function getTier(points: number): string {
  if (points >= 3000) return "platinum";
  if (points >= 1000) return "gold";
  return "silver";
}

function getNextTier(currentTier: string): string | null {
  const tiers = ["silver", "gold", "platinum"];
  const currentIndex = tiers.indexOf(currentTier);
  return currentIndex < tiers.length - 1 ? tiers[currentIndex + 1] : null;
}

function getTierProgress(points: number, tier: string): number {
  if (tier === "silver") {
    return Math.min((points / 1000) * 100, 100);
  } else if (tier === "gold") {
    return Math.min(((points - 1000) / 2000) * 100, 100);
  } else {
    return 100; // Platinum is max tier
  }
}

function getPointsToNextTier(points: number, tier: string): number {
  if (tier === "silver") {
    return 1000 - points;
  } else if (tier === "gold") {
    return 3000 - points;
  }
  return 0; // Already at max tier
}

function getTierDisplay(tier: string): string {
  const displays: Record<string, string> = {
    silver: "Silver Tier",
    gold: "Gold Tier", 
    platinum: "Platinum Tier"
  };
  return displays[tier] || tier;
}
