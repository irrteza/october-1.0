import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Target, 
  Users, 
  TrendingUp, 
  Clock, 
  Zap, 
  Award,
  CheckCircle,
  Lock
} from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  completed: boolean;
  progress?: number;
  maxProgress?: number;
  rarity: "common" | "rare" | "epic" | "legendary";
}

const achievements: Achievement[] = [
  {
    id: "first-campaign",
    title: "Campaign Pioneer",
    description: "Launch your first campaign",
    icon: Target,
    completed: true,
    rarity: "common"
  },
  {
    id: "creator-network",
    title: "Network Builder",
    description: "Connect with 10 creators",
    icon: Users,
    completed: true,
    progress: 10,
    maxProgress: 10,
    rarity: "common"
  },
  {
    id: "roi-master",
    title: "ROI Master",
    description: "Achieve 500% ROI on a campaign",
    icon: TrendingUp,
    completed: false,
    progress: 3,
    maxProgress: 5,
    rarity: "rare"
  },
  {
    id: "speed-demon",
    title: "Speed Demon",
    description: "Complete campaign setup in under 5 minutes",
    icon: Clock,
    completed: true,
    rarity: "rare"
  },
  {
    id: "viral-content",
    title: "Viral Catalyst",
    description: "Generate content with 1M+ views",
    icon: Zap,
    completed: false,
    progress: 1,
    maxProgress: 1,
    rarity: "epic"
  },
  {
    id: "platform-master",
    title: "Platform Master",
    description: "Successfully run campaigns on all major platforms",
    icon: Award,
    completed: false,
    progress: 2,
    maxProgress: 5,
    rarity: "legendary"
  }
];

const rarityColors = {
  common: "bg-gray-500/10 text-gray-600 border-gray-500/20",
  rare: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  epic: "bg-purple-500/10 text-purple-600 border-purple-500/20",
  legendary: "bg-gold/10 text-gold border-gold/20"
};

export default function Achievements() {
  const completedCount = achievements.filter(a => a.completed).length;
  
  return (
    <Card className="hover-glow">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-gold" />
            <span>Achievements</span>
          </span>
          <Badge variant="outline" className="text-gold border-gold/20">
            {completedCount}/{achievements.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {achievements.map((achievement) => {
          const Icon = achievement.icon;
          const isLocked = !achievement.completed && !achievement.progress;
          
          return (
            <div 
              key={achievement.id}
              className={`flex items-center space-x-3 p-3 rounded-2xl border transition-all ${
                achievement.completed 
                  ? "bg-gold/5 border-gold/20" 
                  : isLocked
                  ? "bg-muted/30 border-border opacity-60"
                  : "bg-background border-border"
              }`}
            >
              <div className={`p-2 rounded-full ${
                achievement.completed 
                  ? "bg-gold/10" 
                  : isLocked
                  ? "bg-muted"
                  : "bg-muted/50"
              }`}>
                {achievement.completed ? (
                  <CheckCircle className="w-4 h-4 text-gold" />
                ) : isLocked ? (
                  <Lock className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <Icon className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <h4 className={`font-medium text-sm ${
                    achievement.completed ? "text-foreground" : "text-muted-foreground"
                  }`}>
                    {achievement.title}
                  </h4>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${rarityColors[achievement.rarity]}`}
                  >
                    {achievement.rarity}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground truncate">
                  {achievement.description}
                </p>
                
                {achievement.progress && achievement.maxProgress && !achievement.completed && (
                  <div className="mt-1">
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>{achievement.progress}/{achievement.maxProgress}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-1">
                      <div 
                        className="bg-gold rounded-full h-1 transition-all duration-300"
                        style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}