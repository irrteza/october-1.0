import { Search, Bell, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import RoleSwitcher from "./role-switcher";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  const { user } = useAuth();

  return (
    <header className="bg-background border-b border-border px-8 py-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">{title}</h1>
          {subtitle && (
            <p className="text-muted-foreground mt-1">{subtitle}</p>
          )}
        </div>
        <div className="flex items-center space-x-4">
          <RoleSwitcher />
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search..." 
              className="pl-10 w-64 rounded-2xl"
            />
          </div>
          
          <Button 
            variant="ghost" 
            size="sm"
            className="p-2 text-muted-foreground hover:text-foreground hover:bg-accent rounded-2xl"
          >
            <Bell className="w-5 h-5" />
          </Button>
          
          <Button 
            className="bg-gold hover:bg-gold/90 text-white px-6 py-2 rounded-2xl hover-glow ripple-effect font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Campaign
          </Button>
        </div>
      </div>
    </header>
  );
}
