import { Crown, LayoutDashboard, KanbanSquare, Users, BarChart3, CreditCard, Bot } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import PointsWidget from "@/components/gamification/points-widget";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Campaign Board", href: "/campaigns", icon: KanbanSquare },
    { name: "Creators", href: "/creators", icon: Users },
    { name: "Analytics", href: "/analytics", icon: BarChart3 },
    { name: "Payments", href: "/payments", icon: CreditCard },
    { name: "AI Assistants", href: "/ai-assistants", icon: Bot },
  ];

  const isActive = (href: string) => {
    if (href === "/") {
      return location === "/";
    }
    return location.startsWith(href);
  };

  return (
    <nav className="w-64 bg-light-gray dark:bg-muted border-r border-border flex flex-col">
      {/* Logo Section */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gold rounded-2xl flex items-center justify-center">
            <Crown className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold">October</h1>
        </div>
      </div>

      {/* Navigation Items */}
      <div className="flex-1 px-3 py-6 space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);

          return (
            <Link key={item.name} href={item.href}>
              <div className={`flex items-center px-3 py-2 text-sm font-medium rounded-2xl transition-all duration-250 cursor-pointer hover-glow ${
                active
                  ? "bg-gold text-white"
                  : "text-muted-foreground hover:text-foreground hover:bg-background"
              }`}>
                <Icon className="w-5 h-5 mr-3" />
                {item.name}
              </div>
            </Link>
          );
        })}
      </div>

      {/* Points Widget */}
      <div className="p-3">
        <PointsWidget />
      </div>

      {/* User Profile */}
      <div className="px-3 pb-6">
        <div className="flex items-center p-3 hover:bg-background rounded-2xl cursor-pointer transition-all duration-250">
          <Avatar className="w-10 h-10">
            <AvatarImage src={user?.profileImageUrl} />
            <AvatarFallback>
              {user?.firstName?.charAt(0)}{user?.lastName?.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="ml-3 flex-1">
            <div className="text-sm font-medium">
              {user?.firstName} {user?.lastName}
            </div>
            <div className="text-xs text-muted-foreground capitalize">
              {user?.role}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
