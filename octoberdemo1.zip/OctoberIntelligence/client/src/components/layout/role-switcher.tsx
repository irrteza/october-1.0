import { useAuth } from "@/hooks/useAuth";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Building, Crown, Users } from "lucide-react";
import { setCurrentRole, useCurrentRole } from "../dashboard/role-dashboard";

const roleConfig = {
  owner: {
    label: "Agency Owner",
    icon: Crown,
    color: "bg-gold/10 text-gold border-gold/20"
  },
  manager: {
    label: "Brand Manager", 
    icon: Building,
    color: "bg-blue-500/10 text-blue-600 border-blue-500/20"
  },
  creator: {
    label: "Content Creator",
    icon: Users,
    color: "bg-green-500/10 text-green-600 border-green-500/20"
  }
};

export default function RoleSwitcher() {
  const { user } = useAuth();
  const { toast } = useToast();
  const currentRole = useCurrentRole();

  const handleRoleChange = async (newRole: string) => {
    setCurrentRole(newRole);
    
    toast({
      title: "Role Updated",
      description: `Switched to ${roleConfig[newRole as keyof typeof roleConfig].label}`,
    });
  };

  if (!user) return null;

  const currentConfig = roleConfig[currentRole as keyof typeof roleConfig];
  const Icon = currentConfig.icon;

  return (
    <div className="flex items-center space-x-2">
      <Badge variant="outline" className={currentConfig.color}>
        <Icon className="w-3 h-3 mr-1" />
        {currentConfig.label}
      </Badge>
      
      <Select 
        value={currentRole} 
        onValueChange={handleRoleChange}
      >
        <SelectTrigger className="w-[180px] h-8 text-xs">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {Object.entries(roleConfig).map(([role, config]) => {
            const RoleIcon = config.icon;
            return (
              <SelectItem key={role} value={role}>
                <div className="flex items-center space-x-2">
                  <RoleIcon className="w-3 h-3" />
                  <span className="font-medium">{config.label}</span>
                </div>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
    </div>
  );
}