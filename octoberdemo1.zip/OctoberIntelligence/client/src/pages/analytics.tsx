import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Eye, 
  Users, 
  Download,
  Calendar,
  Target
} from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("30d");
  const [selectedCampaign, setSelectedCampaign] = useState<string>("all");

  const { data: dashboardMetrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ["/api/campaigns"],
  });

  // Mock data for charts (in real app, this would come from API)
  const performanceData = [
    { date: "Jan", views: 120000, engagement: 8500, revenue: 12000 },
    { date: "Feb", views: 150000, engagement: 11200, revenue: 15000 },
    { date: "Mar", views: 180000, engagement: 14800, revenue: 18500 },
    { date: "Apr", views: 220000, engagement: 18900, revenue: 22000 },
    { date: "May", views: 280000, engagement: 24500, revenue: 28000 },
    { date: "Jun", views: 320000, engagement: 29800, revenue: 32000 },
  ];

  const platformData = [
    { name: "YouTube", value: 45, color: "#FF0000" },
    { name: "Instagram", value: 30, color: "#E4405F" },
    { name: "TikTok", value: 20, color: "#000000" },
    { name: "Twitter", value: 5, color: "#1DA1F2" },
  ];

  const roiData = [
    { campaign: "Summer Fashion", spend: 15000, revenue: 45000, roi: 3.0 },
    { campaign: "Tech Reviews", spend: 12000, revenue: 32000, roi: 2.67 },
    { campaign: "Fitness Challenge", spend: 8000, revenue: 20000, roi: 2.5 },
    { campaign: "Beauty Haul", spend: 10000, revenue: 22000, roi: 2.2 },
  ];

  if (metricsLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-gold border-t-transparent rounded-full" />
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        <Header 
          title="Analytics & Insights" 
          subtitle="Track performance and optimize your campaigns"
        />
        
        <div className="flex-1 overflow-y-auto p-8 bg-light-gray dark:bg-muted">
          {/* Controls */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-48 rounded-2xl">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedCampaign} onValueChange={setSelectedCampaign}>
              <SelectTrigger className="w-48 rounded-2xl">
                <SelectValue placeholder="Select campaign" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Campaigns</SelectItem>
                {campaigns.map((campaign: any) => (
                  <SelectItem key={campaign.id} value={campaign.id}>
                    {campaign.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex-1" />

            <Button className="bg-gold hover:bg-gold/90 text-white rounded-2xl hover-glow">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                    <p className="text-3xl font-bold">$247,850</p>
                    <div className="flex items-center mt-2">
                      <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                      <span className="text-sm text-green-600">+12.5%</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Views</p>
                    <p className="text-3xl font-bold">4.2M</p>
                    <div className="flex items-center mt-2">
                      <TrendingUp className="w-4 h-4 text-blue-600 mr-1" />
                      <span className="text-sm text-blue-600">+8.3%</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center">
                    <Eye className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg. ROI</p>
                    <p className="text-3xl font-bold">3.2x</p>
                    <div className="flex items-center mt-2">
                      <TrendingUp className="w-4 h-4 text-gold mr-1" />
                      <span className="text-sm text-gold">+0.4x</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-gold bg-opacity-20 rounded-2xl flex items-center justify-center">
                    <Target className="w-6 h-6 text-gold" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Engagement Rate</p>
                    <p className="text-3xl font-bold">6.8%</p>
                    <div className="flex items-center mt-2">
                      <TrendingDown className="w-4 h-4 text-red-600 mr-1" />
                      <span className="text-sm text-red-600">-0.2%</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="performance" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 rounded-2xl">
              <TabsTrigger value="performance" className="rounded-xl">Performance</TabsTrigger>
              <TabsTrigger value="platforms" className="rounded-xl">Platforms</TabsTrigger>
              <TabsTrigger value="campaigns" className="rounded-xl">Campaigns</TabsTrigger>
              <TabsTrigger value="creators" className="rounded-xl">Creators</TabsTrigger>
            </TabsList>

            <TabsContent value="performance" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Revenue & Views Trend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis yAxisId="left" />
                        <YAxis yAxisId="right" orientation="right" />
                        <Tooltip />
                        <Area
                          yAxisId="left"
                          type="monotone"
                          dataKey="views"
                          stackId="1"
                          stroke="hsl(37, 35%, 60%)"
                          fill="hsl(37, 35%, 60%)"
                          fillOpacity={0.3}
                        />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="revenue"
                          stroke="hsl(142, 76%, 36%)"
                          strokeWidth={3}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Engagement Over Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Area
                          type="monotone"
                          dataKey="engagement"
                          stroke="hsl(262, 83%, 58%)"
                          fill="hsl(262, 83%, 58%)"
                          fillOpacity={0.3}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="platforms" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Platform Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={platformData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {platformData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Platform Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {platformData.map((platform) => (
                        <div key={platform.name} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: platform.color }}
                            />
                            <span className="font-medium">{platform.name}</span>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">{platform.value}%</p>
                            <p className="text-sm text-muted-foreground">of total views</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="campaigns" className="space-y-6">
              <Card className="hover-glow">
                <CardHeader>
                  <CardTitle>Campaign ROI Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={roiData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="campaign" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="roi" fill="hsl(37, 35%, 60%)" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {roiData.map((campaign) => (
                  <Card key={campaign.campaign} className="hover-glow">
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">{campaign.campaign}</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Spend:</span>
                          <span>${campaign.spend.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Revenue:</span>
                          <span className="text-green-600">${campaign.revenue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">ROI:</span>
                          <Badge className="bg-gold text-white">{campaign.roi}x</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="creators" className="space-y-6">
              <div className="text-center py-12">
                <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Creator Analytics</h3>
                <p className="text-muted-foreground">
                  Detailed creator performance metrics coming soon
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
