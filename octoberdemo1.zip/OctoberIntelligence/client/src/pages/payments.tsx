import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  CreditCard, 
  Download, 
  Filter, 
  Search, 
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Calendar,
  TrendingUp
} from "lucide-react";
import { format } from "date-fns";

export default function Payments() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: invoices = [], isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/invoices"],
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ["/api/campaigns"],
  });

  const filteredInvoices = invoices.filter((invoice: any) => {
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    const matchesSearch = invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.amount.toString().includes(searchTerm);
    return matchesStatus && matchesSearch;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "paid":
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-red-600" />;
      case "cancelled":
        return <XCircle className="w-4 h-4 text-gray-600" />;
      default:
        return <AlertCircle className="w-4 h-4 text-blue-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      paid: "bg-green-100 text-green-700",
      pending: "bg-yellow-100 text-yellow-700", 
      failed: "bg-red-100 text-red-700",
      cancelled: "bg-gray-100 text-gray-700",
      draft: "bg-blue-100 text-blue-700"
    };

    return (
      <Badge className={variants[status] || "bg-gray-100 text-gray-700"}>
        <div className="flex items-center space-x-1">
          {getStatusIcon(status)}
          <span className="capitalize">{status}</span>
        </div>
      </Badge>
    );
  };

  // Calculate summary metrics
  const totalPaid = invoices
    .filter((inv: any) => inv.status === "paid")
    .reduce((sum: number, inv: any) => sum + parseFloat(inv.amount), 0);

  const totalPending = invoices
    .filter((inv: any) => inv.status === "pending")
    .reduce((sum: number, inv: any) => sum + parseFloat(inv.amount), 0);

  const totalInvoices = invoices.length;
  const paidInvoices = invoices.filter((inv: any) => inv.status === "paid").length;

  if (invoicesLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-gold border-t-transparent rounded-full" />
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        <Header 
          title="Payments & Invoices" 
          subtitle="Manage payments and track financial transactions"
        />
        
        <div className="flex-1 overflow-y-auto p-8 bg-light-gray dark:bg-muted">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Paid</p>
                    <p className="text-3xl font-bold">${totalPaid.toLocaleString()}</p>
                    <p className="text-sm text-green-600 mt-1">+12.5% from last month</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Pending</p>
                    <p className="text-3xl font-bold">${totalPending.toLocaleString()}</p>
                    <p className="text-sm text-yellow-600 mt-1">{invoices.filter((inv: any) => inv.status === "pending").length} invoices</p>
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-2xl flex items-center justify-center">
                    <Clock className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                    <p className="text-3xl font-bold">{totalInvoices > 0 ? Math.round((paidInvoices / totalInvoices) * 100) : 0}%</p>
                    <p className="text-sm text-blue-600 mt-1">{paidInvoices} of {totalInvoices} paid</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg. Invoice</p>
                    <p className="text-3xl font-bold">
                      ${totalInvoices > 0 ? Math.round(invoices.reduce((sum: number, inv: any) => sum + parseFloat(inv.amount), 0) / totalInvoices) : 0}
                    </p>
                    <p className="text-sm text-purple-600 mt-1">Per transaction</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters and Search */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search by invoice number or amount..." 
                className="pl-10 rounded-2xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48 rounded-2xl">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-gold hover:bg-gold/90 text-white rounded-2xl hover-glow">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>

          <Tabs defaultValue="invoices" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 rounded-2xl">
              <TabsTrigger value="invoices" className="rounded-xl">Invoices</TabsTrigger>
              <TabsTrigger value="payouts" className="rounded-xl">Creator Payouts</TabsTrigger>
              <TabsTrigger value="settings" className="rounded-xl">Payment Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="invoices">
              <Card className="hover-glow">
                <CardHeader>
                  <CardTitle>Invoice History</CardTitle>
                </CardHeader>
                <CardContent>
                  {filteredInvoices.length === 0 ? (
                    <div className="text-center py-12">
                      <CreditCard className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No Invoices Found</h3>
                      <p className="text-muted-foreground">
                        {searchTerm || statusFilter !== "all" 
                          ? "Try adjusting your search or filter criteria"
                          : "No invoices have been created yet"
                        }
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredInvoices.map((invoice: any) => (
                        <div 
                          key={invoice.id}
                          className="flex items-center justify-between p-4 border border-border rounded-2xl hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-gold bg-opacity-10 rounded-2xl flex items-center justify-center">
                              <CreditCard className="w-6 h-6 text-gold" />
                            </div>
                            <div>
                              <h3 className="font-semibold">{invoice.invoiceNumber}</h3>
                              <p className="text-sm text-muted-foreground">
                                Created {format(new Date(invoice.createdAt), "MMM dd, yyyy")}
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-6">
                            <div className="text-right">
                              <p className="font-semibold">${parseFloat(invoice.amount).toLocaleString()}</p>
                              {invoice.dueDate && (
                                <p className="text-sm text-muted-foreground">
                                  Due {format(new Date(invoice.dueDate), "MMM dd")}
                                </p>
                              )}
                            </div>
                            
                            {getStatusBadge(invoice.status)}
                            
                            <Button variant="ghost" size="sm" className="rounded-xl">
                              View Details
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payouts">
              <Card className="hover-glow">
                <CardHeader>
                  <CardTitle>Creator Payouts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <DollarSign className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Payout Management</h3>
                    <p className="text-muted-foreground mb-4">
                      Configure and manage automated creator payouts
                    </p>
                    <Button className="bg-gold hover:bg-gold/90 text-white rounded-2xl">
                      Setup Stripe Connect
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Payment Methods</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 border border-border rounded-2xl">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                              <CreditCard className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-medium">Stripe</p>
                              <p className="text-sm text-muted-foreground">Connected</p>
                            </div>
                          </div>
                          <Badge className="bg-green-100 text-green-700">Active</Badge>
                        </div>
                      </div>
                      
                      <Button variant="outline" className="w-full rounded-2xl">
                        Add Payment Method
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Invoice Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Default Payment Terms</label>
                        <Select defaultValue="net30">
                          <SelectTrigger className="mt-1 rounded-xl">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="immediate">Due Immediately</SelectItem>
                            <SelectItem value="net15">Net 15 days</SelectItem>
                            <SelectItem value="net30">Net 30 days</SelectItem>
                            <SelectItem value="net60">Net 60 days</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Auto-generate Invoices</label>
                        <Select defaultValue="approval">
                          <SelectTrigger className="mt-1 rounded-xl">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="approval">On Content Approval</SelectItem>
                            <SelectItem value="delivery">On Delivery</SelectItem>
                            <SelectItem value="manual">Manual Only</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Button className="w-full bg-gold hover:bg-gold/90 text-white rounded-2xl">
                        Save Settings
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
