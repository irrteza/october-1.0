import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, Search, Star, TrendingUp, Users } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function Creators() {
  const { data: creators = [], isLoading } = useQuery({
    queryKey: ["/api/creators"],
  });

  if (isLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-gold border-t-transparent rounded-full" />
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        <Header 
          title="Creator Network" 
          subtitle="Discover and manage your creator partnerships"
        />
        
        <div className="flex-1 overflow-y-auto p-8 bg-light-gray dark:bg-muted">
          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search creators by name, platform, or niche..." 
                className="pl-10 rounded-2xl"
              />
            </div>
            <Button className="bg-gold hover:bg-gold/90 text-white px-6 rounded-2xl">
              <Plus className="w-4 h-4 mr-2" />
              Add Creator
            </Button>
          </div>

          {/* Creator Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Creators</p>
                    <p className="text-3xl font-bold">{creators.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active This Month</p>
                    <p className="text-3xl font-bold">{creators.filter((c: any) => c.isActive).length}</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Top Performers</p>
                    <p className="text-3xl font-bold">
                      {creators.filter((c: any) => parseFloat(c.totalEarnings) > 5000).length}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-gold bg-opacity-20 rounded-2xl flex items-center justify-center">
                    <Star className="w-6 h-6 text-gold" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-glow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg. Rate</p>
                    <p className="text-3xl font-bold">
                      ${Math.round(creators.reduce((acc: number, c: any) => acc + (parseFloat(c.averageRate) || 0), 0) / creators.length || 0)}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Creator Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {creators.map((creator: any) => (
              <Card key={creator.id} className="hover-glow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4 mb-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${creator.stageName}`} />
                      <AvatarFallback>{creator.stageName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{creator.stageName}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{creator.bio}</p>
                      <div className="flex items-center space-x-2">
                        {creator.isActive ? (
                          <Badge className="bg-green-100 text-green-700">Active</Badge>
                        ) : (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Social Platforms */}
                  <div className="mb-4">
                    <p className="text-sm font-medium mb-2">Platforms</p>
                    <div className="flex flex-wrap gap-2">
                      {creator.socialProfiles?.map((profile: any, index: number) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {profile.platform}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Specialties */}
                  {creator.specialties && (
                    <div className="mb-4">
                      <p className="text-sm font-medium mb-2">Specialties</p>
                      <div className="flex flex-wrap gap-2">
                        {creator.specialties.slice(0, 3).map((specialty: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Performance Metrics */}
                  <div className="border-t pt-4">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-xs text-muted-foreground">Total Earnings</p>
                        <p className="font-semibold">${creator.totalEarnings || '0'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Avg. Rate</p>
                        <p className="font-semibold">${creator.averageRate || '0'}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {creators.length === 0 && (
            <div className="flex items-center justify-center h-64 bg-card rounded-2xl border border-border">
              <div className="text-center">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Creators Found</h3>
                <p className="text-muted-foreground mb-4">Start building your creator network</p>
                <Button className="bg-gold hover:bg-gold/90 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Creator
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
