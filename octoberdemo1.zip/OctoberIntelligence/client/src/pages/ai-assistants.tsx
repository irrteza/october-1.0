import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search, 
  Edit3, 
  Calculator, 
  Sparkles, 
  Bot,
  TrendingUp,
  Users,
  Target,
  Zap,
  Brain,
  Lightbulb
} from "lucide-react";

export default function AIAssistants() {
  const [creatorMatchQuery, setCreatorMatchQuery] = useState("");
  const [briefCopilotUrl, setBriefCopilotUrl] = useState("");
  const [rateAdvisorData, setRateAdvisorData] = useState({
    platform: "",
    followers: "",
    engagement: "",
    niche: ""
  });

  const [isLoadingMatch, setIsLoadingMatch] = useState(false);
  const [isLoadingBrief, setIsLoadingBrief] = useState(false);
  const [isLoadingRate, setIsLoadingRate] = useState(false);

  const handleCreatorMatch = async () => {
    setIsLoadingMatch(true);
    // In real implementation, call API
    setTimeout(() => {
      setIsLoadingMatch(false);
    }, 2000);
  };

  const handleBriefGeneration = async () => {
    setIsLoadingBrief(true);
    // In real implementation, call API
    setTimeout(() => {
      setIsLoadingBrief(false);
    }, 2000);
  };

  const handleRateRecommendation = async () => {
    setIsLoadingRate(true);
    // In real implementation, call API
    setTimeout(() => {
      setIsLoadingRate(false);
    }, 2000);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        <Header 
          title="AI Assistants" 
          subtitle="Leverage AI-powered tools to optimize your campaigns"
        />
        
        <div className="flex-1 overflow-y-auto p-8 bg-light-gray dark:bg-muted">
          {/* AI Tools Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="hover-glow border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                    <Search className="w-6 h-6 text-purple-600" />
                  </div>
                  <Badge className="bg-purple-100 text-purple-700">AI Powered</Badge>
                </div>
                <h3 className="text-lg font-bold mb-2">Creator Match</h3>
                <p className="text-sm text-muted-foreground">
                  Find similar creators using AI-powered analysis of audience demographics and content style
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                    <Edit3 className="w-6 h-6 text-green-600" />
                  </div>
                  <Badge className="bg-green-100 text-green-700">Smart Content</Badge>
                </div>
                <h3 className="text-lg font-bold mb-2">Brief Copilot</h3>
                <p className="text-sm text-muted-foreground">
                  Generate comprehensive content briefs from product URLs with AI-powered insights
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow border-gold">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gold bg-opacity-20 rounded-2xl flex items-center justify-center">
                    <Calculator className="w-6 h-6 text-gold" />
                  </div>
                  <Badge className="bg-gold bg-opacity-20 text-gold">Pricing AI</Badge>
                </div>
                <h3 className="text-lg font-bold mb-2">Rate Advisor</h3>
                <p className="text-sm text-muted-foreground">
                  Get fair pricing recommendations based on market data and creator performance
                </p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="creator-match" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 rounded-2xl">
              <TabsTrigger value="creator-match" className="rounded-xl">Creator Match</TabsTrigger>
              <TabsTrigger value="brief-copilot" className="rounded-xl">Brief Copilot</TabsTrigger>
              <TabsTrigger value="rate-advisor" className="rounded-xl">Rate Advisor</TabsTrigger>
            </TabsList>

            <TabsContent value="creator-match" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Search className="w-5 h-5 text-purple-600" />
                      <span>Find Similar Creators</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Reference Creator</label>
                      <Input 
                        placeholder="Enter creator name or ID..."
                        value={creatorMatchQuery}
                        onChange={(e) => setCreatorMatchQuery(e.target.value)}
                        className="rounded-2xl"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium mb-2 block">Platform</label>
                      <Select>
                        <SelectTrigger className="rounded-2xl">
                          <SelectValue placeholder="Select platform" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="youtube">YouTube</SelectItem>
                          <SelectItem value="instagram">Instagram</SelectItem>
                          <SelectItem value="tiktok">TikTok</SelectItem>
                          <SelectItem value="twitter">Twitter</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Target Audience</label>
                      <Input 
                        placeholder="e.g., Fashion enthusiasts, 18-35"
                        className="rounded-2xl"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Budget Range</label>
                      <Input 
                        placeholder="e.g., $1000 - $5000"
                        className="rounded-2xl"
                      />
                    </div>

                    <Button 
                      onClick={handleCreatorMatch}
                      disabled={isLoadingMatch || !creatorMatchQuery}
                      className="w-full bg-purple-600 hover:bg-purple-700 text-white rounded-2xl"
                    >
                      {isLoadingMatch ? (
                        <>
                          <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Find Similar Creators
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>AI Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!isLoadingMatch ? (
                      <div className="text-center py-8">
                        <Bot className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-semibold mb-2">Ready to Analyze</h3>
                        <p className="text-muted-foreground">
                          Enter a reference creator to get AI-powered recommendations
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="brief-copilot" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Edit3 className="w-5 h-5 text-green-600" />
                      <span>Generate Content Brief</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Product URL</label>
                      <Input 
                        placeholder="https://example.com/product"
                        value={briefCopilotUrl}
                        onChange={(e) => setBriefCopilotUrl(e.target.value)}
                        className="rounded-2xl"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium mb-2 block">Brand Name</label>
                      <Input 
                        placeholder="Your brand name"
                        className="rounded-2xl"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Target Audience</label>
                      <Textarea 
                        placeholder="Describe your target audience..."
                        className="rounded-2xl"
                        rows={3}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Content Platform</label>
                      <Select>
                        <SelectTrigger className="rounded-2xl">
                          <SelectValue placeholder="Select platform" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="youtube">YouTube Video</SelectItem>
                          <SelectItem value="instagram">Instagram Post</SelectItem>
                          <SelectItem value="tiktok">TikTok Video</SelectItem>
                          <SelectItem value="stories">Instagram Stories</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button 
                      onClick={handleBriefGeneration}
                      disabled={isLoadingBrief || !briefCopilotUrl}
                      className="w-full bg-green-600 hover:bg-green-700 text-white rounded-2xl"
                    >
                      {isLoadingBrief ? (
                        <>
                          <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Brain className="w-4 h-4 mr-2" />
                          Generate Brief
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Generated Brief</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!isLoadingBrief ? (
                      <div className="text-center py-8">
                        <Lightbulb className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-semibold mb-2">AI Brief Generator</h3>
                        <p className="text-muted-foreground">
                          Provide a product URL to generate a comprehensive content brief
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="rate-advisor" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Calculator className="w-5 h-5 text-gold" />
                      <span>Get Rate Recommendation</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Platform</label>
                      <Select 
                        value={rateAdvisorData.platform}
                        onValueChange={(value) => setRateAdvisorData({...rateAdvisorData, platform: value})}
                      >
                        <SelectTrigger className="rounded-2xl">
                          <SelectValue placeholder="Select platform" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="youtube">YouTube</SelectItem>
                          <SelectItem value="instagram">Instagram</SelectItem>
                          <SelectItem value="tiktok">TikTok</SelectItem>
                          <SelectItem value="twitter">Twitter</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium mb-2 block">Followers Count</label>
                      <Input 
                        placeholder="e.g., 50000"
                        value={rateAdvisorData.followers}
                        onChange={(e) => setRateAdvisorData({...rateAdvisorData, followers: e.target.value})}
                        className="rounded-2xl"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Engagement Rate (%)</label>
                      <Input 
                        placeholder="e.g., 3.5"
                        value={rateAdvisorData.engagement}
                        onChange={(e) => setRateAdvisorData({...rateAdvisorData, engagement: e.target.value})}
                        className="rounded-2xl"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Niche</label>
                      <Select 
                        value={rateAdvisorData.niche}
                        onValueChange={(value) => setRateAdvisorData({...rateAdvisorData, niche: value})}
                      >
                        <SelectTrigger className="rounded-2xl">
                          <SelectValue placeholder="Select niche" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fashion">Fashion & Beauty</SelectItem>
                          <SelectItem value="tech">Technology</SelectItem>
                          <SelectItem value="fitness">Fitness & Health</SelectItem>
                          <SelectItem value="food">Food & Lifestyle</SelectItem>
                          <SelectItem value="travel">Travel</SelectItem>
                          <SelectItem value="gaming">Gaming</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Content Type</label>
                      <Select>
                        <SelectTrigger className="rounded-2xl">
                          <SelectValue placeholder="Select content type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="post">Single Post</SelectItem>
                          <SelectItem value="video">Video Content</SelectItem>
                          <SelectItem value="stories">Stories</SelectItem>
                          <SelectItem value="reel">Reel/Short Video</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button 
                      onClick={handleRateRecommendation}
                      disabled={isLoadingRate || !rateAdvisorData.platform || !rateAdvisorData.followers}
                      className="w-full bg-gold hover:bg-gold/90 text-white rounded-2xl"
                    >
                      {isLoadingRate ? (
                        <>
                          <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                          Calculating...
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 mr-2" />
                          Get Rate Recommendation
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="hover-glow">
                  <CardHeader>
                    <CardTitle>Rate Recommendation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!isLoadingRate ? (
                      <div className="text-center py-8">
                        <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-semibold mb-2">AI Rate Calculator</h3>
                        <p className="text-muted-foreground">
                          Enter creator details to get data-driven pricing recommendations
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="animate-pulse">
                          <div className="h-8 bg-gray-200 rounded w-1/2 mb-4"></div>
                          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          {/* AI Usage Stats */}
          <Card className="hover-glow mt-8">
            <CardHeader>
              <CardTitle>AI Assistant Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="font-semibold mb-2">Creator Matches</h3>
                  <p className="text-2xl font-bold text-purple-600">47</p>
                  <p className="text-sm text-muted-foreground">This month</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Edit3 className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold mb-2">Briefs Generated</h3>
                  <p className="text-2xl font-bold text-green-600">23</p>
                  <p className="text-sm text-muted-foreground">This month</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-gold bg-opacity-20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Calculator className="w-8 h-8 text-gold" />
                  </div>
                  <h3 className="font-semibold mb-2">Rate Recommendations</h3>
                  <p className="text-2xl font-bold text-gold">31</p>
                  <p className="text-sm text-muted-foreground">This month</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
