import { Crown, Users, BarChart3, Bot, CreditCard, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gold rounded-2xl flex items-center justify-center">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold">October</h1>
            </div>
            <Button
              onClick={() => window.location.href = "/api/login"}
              className="bg-gold hover:bg-gold/90 text-white px-8 py-2 rounded-2xl hover-glow ripple-effect"
            >
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-fade-in">
            <h1 className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-charcoal via-gold to-charcoal bg-clip-text text-transparent">
              Premium Influencer Marketing
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              October brings together brands, agencies, and creators with AI-powered tools, 
              real-time collaboration, and gamified experiences that drive exceptional results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                className="bg-gold hover:bg-gold/90 text-white px-8 py-4 rounded-2xl text-lg hover-glow ripple-effect"
              >
                Start Your Campaign
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-gold text-gold hover:bg-gold hover:text-white px-8 py-4 rounded-2xl text-lg"
              >
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-6 bg-light-gray dark:bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-4xl font-bold mb-4">Everything You Need to Scale</h2>
            <p className="text-xl text-muted-foreground">
              From campaign management to AI-powered insights, October has you covered.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover-glow animate-slide-up">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold mb-4">Unified Campaign Board</h3>
                <p className="text-muted-foreground">
                  Real-time Kanban board with drag-drop functionality. Track deliverables 
                  from brief to payment with live synchronization.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow animate-slide-up">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                  <Bot className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-4">AI Assistants</h3>
                <p className="text-muted-foreground">
                  Creator Match finds similar talent, Brief Copilot generates content specs, 
                  and Rate Advisor ensures fair pricing.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow animate-slide-up">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center mb-6">
                  <BarChart3 className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="text-xl font-bold mb-4">Advanced Analytics</h3>
                <p className="text-muted-foreground">
                  Cross-platform metrics ingestion with ROI tracking, profitability analysis, 
                  and performance prediction.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow animate-slide-up">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gold bg-opacity-20 rounded-2xl flex items-center justify-center mb-6">
                  <Crown className="w-6 h-6 text-gold" />
                </div>
                <h3 className="text-xl font-bold mb-4">October Elite Gamification</h3>
                <p className="text-muted-foreground">
                  Earn points for every action. Unlock perks like fee discounts, 
                  early payouts, and AI credits as you level up.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow animate-slide-up">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-yellow-100 rounded-2xl flex items-center justify-center mb-6">
                  <CreditCard className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="text-xl font-bold mb-4">Smart Payment Orchestration</h3>
                <p className="text-muted-foreground">
                  Automated payouts with Stripe Connect. Configurable payment rules 
                  and milestone-based releases.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-glow animate-slide-up">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center mb-6">
                  <CheckCircle className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="text-xl font-bold mb-4">Role-Based Access</h3>
                <p className="text-muted-foreground">
                  Creators see their cards, brands manage portfolios, agencies handle 
                  bulk operations. Everyone gets the right view.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Tiers */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Choose Your Tier</h2>
            <p className="text-xl text-muted-foreground">
              Start free and scale with October Elite rewards.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="hover-glow">
              <CardContent className="p-8 text-center">
                <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl">🥈</span>
                </div>
                <h3 className="text-2xl font-bold mb-2">Silver</h3>
                <p className="text-muted-foreground mb-6">0-999 points</p>
                <ul className="space-y-2 text-left">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Basic dashboard access
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Standard support
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Campaign management
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover-glow border-gold">
              <CardContent className="p-8 text-center">
                <div className="w-12 h-12 bg-gold bg-opacity-20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl">🥇</span>
                </div>
                <h3 className="text-2xl font-bold mb-2 text-gold">Gold</h3>
                <p className="text-muted-foreground mb-6">1000-2999 points</p>
                <ul className="space-y-2 text-left">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    All Silver features
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    AI assistant access
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    5% fee discount
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Priority support
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover-glow border-purple-500">
              <CardContent className="p-8 text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl">💎</span>
                </div>
                <h3 className="text-2xl font-bold mb-2 text-purple-600">Platinum</h3>
                <p className="text-muted-foreground mb-6">3000+ points</p>
                <ul className="space-y-2 text-left">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    All Gold features
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Early payout access
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    10% fee discount
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Dedicated account manager
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gold text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Transform Your Influencer Marketing?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join the platform that's redefining how brands, agencies, and creators collaborate.
          </p>
          <Button
            size="lg"
            onClick={() => window.location.href = "/api/login"}
            className="bg-white text-gold hover:bg-gray-100 px-8 py-4 rounded-2xl text-lg hover-glow ripple-effect"
          >
            Get Started Free
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gold rounded-xl flex items-center justify-center">
                <Crown className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold">October</span>
            </div>
            <p className="text-muted-foreground">
              © 2024 October. Premium influencer marketing platform.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
