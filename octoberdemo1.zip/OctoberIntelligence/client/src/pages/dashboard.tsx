import { useEffect } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import RoleDashboard from "@/components/dashboard/role-dashboard";
import { useAuth } from "@/hooks/useAuth";
import { useWebSocket } from "@/hooks/useWebSocket";

export default function Dashboard() {
  const { user } = useAuth();
  const { isConnected, lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      console.log("Received WebSocket message:", lastMessage);
    }
  }, [lastMessage]);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        <Header 
          title="Campaign Dashboard" 
          subtitle="Monitor your influencer marketing campaigns in real-time"
        />
        
        <div className="flex-1 overflow-y-auto p-8 bg-light-gray dark:bg-muted">
          <RoleDashboard />
        </div>
      </main>
    </div>
  );
}
