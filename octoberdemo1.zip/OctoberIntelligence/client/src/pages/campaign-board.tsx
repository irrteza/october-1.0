import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import KanbanLane from "@/components/kanban/kanban-lane";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Filter, MoreHorizontal } from "lucide-react";

export default function CampaignBoard() {
  const [selectedCampaign, setSelectedCampaign] = useState<string | null>(null);

  const { data: campaigns = [] } = useQuery({
    queryKey: ["/api/campaigns"],
  });

  const { data: deliverables = [] } = useQuery({
    queryKey: ["/api/deliverables", selectedCampaign],
    enabled: !!selectedCampaign,
  });

  const lanes = [
    { id: "brief", title: "Brief", status: "brief" },
    { id: "draft", title: "Draft", status: "draft" },
    { id: "approved", title: "Approved", status: "approved" },
    { id: "live", title: "Live", status: "live" },
    { id: "paid", title: "Paid", status: "paid" },
  ];

  const getDeliverablesForLane = (status: string) => {
    return deliverables.filter((d: any) => d.status === status);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        <Header 
          title="Campaign Board" 
          subtitle="Manage deliverables across all campaign stages"
        />
        
        <div className="flex-1 overflow-hidden p-8 bg-light-gray dark:bg-muted">
          {/* Campaign Selector */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Select Campaign</h2>
              <Button className="bg-gold hover:bg-gold/90 text-white">
                <Plus className="w-4 h-4 mr-2" />
                New Campaign
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {campaigns.map((campaign: any) => (
                <div
                  key={campaign.id}
                  onClick={() => setSelectedCampaign(campaign.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all hover:shadow-lg ${
                    selectedCampaign === campaign.id
                      ? "border-gold bg-gold/10"
                      : "border-border bg-card hover:border-gold/50"
                  }`}
                >
                  <h3 className="font-semibold mb-2">{campaign.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{campaign.description}</p>
                  <div className="flex items-center justify-between text-xs">
                    <span className={`px-2 py-1 rounded-full ${
                      campaign.status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"
                    }`}>
                      {campaign.status}
                    </span>
                    <span className="text-muted-foreground">${campaign.budget}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Kanban Board */}
          {selectedCampaign && (
            <div className="bg-card rounded-2xl p-6 shadow-sm border border-border h-full">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Campaign Board</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <Filter className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-5 gap-4 h-full overflow-x-auto">
                {lanes.map((lane) => (
                  <KanbanLane
                    key={lane.id}
                    title={lane.title}
                    status={lane.status}
                    deliverables={getDeliverablesForLane(lane.status)}
                    campaignId={selectedCampaign}
                  />
                ))}
              </div>
            </div>
          )}

          {!selectedCampaign && (
            <div className="flex items-center justify-center h-64 bg-card rounded-2xl border border-border">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Select a Campaign</h3>
                <p className="text-muted-foreground">Choose a campaign above to view its board</p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
