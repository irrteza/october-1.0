// Mock authentication for demo purposes
export function useAuth() {
  const mockUser = {
    id: "demo-user-1",
    email: "demo@october.com",
    firstName: "Moe",
    lastName: "Sarue",
    profileImageUrl: null,
    role: "owner",
    tier: "gold",
    points: 750,
    createdAt: new Date(),
    updatedAt: new Date()
  };

  return {
    user: mockUser,
    isLoading: false,
    isAuthenticated: true,
  };
}
